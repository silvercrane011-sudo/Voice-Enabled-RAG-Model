"""
STT provider module.

Provider choice: SARVAM AI (free tier) is the primary provider for this pipeline.

Justification (one paragraph, as required):
Sarvam AI's free tier is chosen over ElevenLabs for this use case because Sarvam
is purpose-built for STT (their "Saarika" ASR models) with a free developer quota
denominated in request volume, low-latency short-utterance transcription, and
first-class support for Indian-language / code-switched speech, whereas
ElevenLabs' free tier is primarily budgeted for TTS characters and only recently
added STT ("Scribe") with a much smaller shared free-tier minute allowance that
is consumed faster in a multi-user RAG pipeline context. For a query-driven
voice-to-answer pipeline where turns are short (a few seconds of speech) and
volume of *requests* matters more than minutes of audio, Sarvam's per-request
free quota stretches further than ElevenLabs' per-minute free quota. Both are
free-tier viable; Sarvam is the default, ElevenLabs remains a drop-in alternate
(see `transcribe(..., provider="elevenlabs")`), and faster-whisper is the
always-available local fallback if either cloud quota is exhausted.

Free-tier limits (state explicitly, verify against provider docs before prod use):
  - Sarvam AI free tier: limited requests/day per API key (exact number varies
    by plan tier at signup time — check https://docs.sarvam.ai for current cap).
  - ElevenLabs free tier: limited shared credits/month across all audio
    features (TTS + STT draw from the same pool) — check https://elevenlabs.io/pricing.
  - Local fallback (faster-whisper): no quota, bounded only by CPU time.
"""
import time
import logging
from dataclasses import dataclass
from typing import Optional

import requests

from config import CONFIG
from stt.errors import STTProviderError, STTAllProvidersExhaustedError
from stt.validation import validate_audio_file, AudioMeta
from stt.local_fallback import transcribe_local

logger = logging.getLogger("stt.provider")


@dataclass
class STTResult:
    text: str
    provider: str          # "sarvam" | "elevenlabs" | "local_fallback"
    language: Optional[str]
    duration_seconds: Optional[float]
    attempts: int
    latency_ms: float
    audio_meta: AudioMeta


def _call_sarvam(audio_path: str) -> dict:
    cfg = CONFIG.stt
    if not cfg.sarvam_api_key:
        raise STTProviderError("SARVAM_API_KEY not set in environment")
    with open(audio_path, "rb") as f:
        files = {"file": f}
        headers = {"api-subscription-key": cfg.sarvam_api_key}
        resp = requests.post(
            cfg.sarvam_endpoint,
            files=files,
            headers=headers,
            timeout=cfg.request_timeout_seconds,
        )
    if resp.status_code == 429:
        raise STTProviderError("Sarvam free-tier quota exhausted (HTTP 429)")
    if not resp.ok:
        raise STTProviderError(f"Sarvam API error {resp.status_code}: {resp.text[:200]}")
    data = resp.json()
    return {
        "text": data.get("transcript", ""),
        "language": data.get("language_code"),
    }


def _call_elevenlabs(audio_path: str) -> dict:
    cfg = CONFIG.stt
    if not cfg.elevenlabs_api_key:
        raise STTProviderError("ELEVENLABS_API_KEY not set in environment")
    with open(audio_path, "rb") as f:
        files = {"file": f}
        headers = {"xi-api-key": cfg.elevenlabs_api_key}
        data = {"model_id": "scribe_v1"}
        resp = requests.post(
            cfg.elevenlabs_endpoint,
            files=files,
            data=data,
            headers=headers,
            timeout=cfg.request_timeout_seconds,
        )
    if resp.status_code == 429:
        raise STTProviderError("ElevenLabs free-tier credits exhausted (HTTP 429)")
    if not resp.ok:
        raise STTProviderError(f"ElevenLabs API error {resp.status_code}: {resp.text[:200]}")
    payload = resp.json()
    return {
        "text": payload.get("text", ""),
        "language": payload.get("language_code"),
    }


_PROVIDER_FUNCS = {
    "sarvam": _call_sarvam,
    "elevenlabs": _call_elevenlabs,
}


def _call_with_retry(provider: str, audio_path: str, cfg) -> dict:
    """Timeout + retry with exponential backoff (max cfg.max_retries retries)."""
    fn = _PROVIDER_FUNCS[provider]
    last_err = None
    for attempt in range(cfg.max_retries + 1):
        try:
            return fn(audio_path)
        except (requests.Timeout, requests.ConnectionError, STTProviderError) as e:
            last_err = e
            if attempt < cfg.max_retries:
                sleep_s = cfg.backoff_base_seconds * (2 ** attempt)
                logger.warning(
                    "%s STT attempt %d/%d failed (%s); retrying in %.2fs",
                    provider, attempt + 1, cfg.max_retries + 1, e, sleep_s,
                )
                time.sleep(sleep_s)
            else:
                logger.error("%s STT exhausted all %d attempts", provider, cfg.max_retries + 1)
    raise STTProviderError(f"{provider} failed after retries: {last_err}")


def transcribe(audio_path: str, provider: Optional[str] = None) -> STTResult:
    """
    Full pipeline entrypoint: validate -> try cloud provider (with retry) ->
    fall back to local faster-whisper on any failure. Never raises unless
    BOTH the cloud path and local fallback fail (graceful degradation).
    """
    cfg = CONFIG.stt
    provider = provider or cfg.provider
    t0 = time.perf_counter()

    audio_meta = validate_audio_file(audio_path)

    attempts_used = 0
    try:
        attempts_used = 1
        result = _call_with_retry(provider, audio_path, cfg)
        latency_ms = (time.perf_counter() - t0) * 1000
        return STTResult(
            text=result["text"],
            provider=provider,
            language=result.get("language"),
            duration_seconds=audio_meta.duration_seconds,
            attempts=attempts_used,
            latency_ms=round(latency_ms, 2),
            audio_meta=audio_meta,
        )
    except STTProviderError as e:
        logger.warning("Cloud provider '%s' unavailable (%s) — using local fallback", provider, e)
        try:
            local_result = transcribe_local(audio_path)
        except STTAllProvidersExhaustedError:
            raise  # both paths exhausted — surfaces to orchestrator for graceful handling

        latency_ms = (time.perf_counter() - t0) * 1000
        return STTResult(
            text=local_result["text"],
            provider="local_fallback",
            language=local_result.get("language"),
            duration_seconds=audio_meta.duration_seconds,
            attempts=attempts_used + 1,
            latency_ms=round(latency_ms, 2),
            audio_meta=audio_meta,
        )
