"""
Fully local, free, offline ASR fallback using faster-whisper (CTranslate2-based
Whisper implementation — MIT licensed, no API key, no per-call cost).
Used when:
  (a) the chosen cloud STT provider's free tier is exhausted, or
  (b) the cloud call fails after all retries.

Model is loaded lazily and cached at module level so repeated calls in a
single process don't pay reload cost.
"""
import logging
from typing import Optional

from stt.errors import STTAllProvidersExhaustedError

logger = logging.getLogger("stt.local_fallback")

_MODEL_CACHE = {}


def _get_model(model_size: str = "small"):
    if model_size in _MODEL_CACHE:
        return _MODEL_CACHE[model_size]
    try:
        from faster_whisper import WhisperModel
    except ImportError as e:
        raise STTAllProvidersExhaustedError(
            "faster-whisper not installed. Install with: "
            "pip install faster-whisper --break-system-packages"
        ) from e

    # CPU + int8 quantization = works free on commodity hardware, no GPU needed
    model = WhisperModel(model_size, device="cpu", compute_type="int8")
    _MODEL_CACHE[model_size] = model
    return model


def transcribe_local(audio_path: str, model_size: str = "small") -> dict:
    """
    Returns dict: {"text": str, "segments": [...], "language": str, "provider": "local_fallback"}
    Raises STTAllProvidersExhaustedError if the local model itself fails
    (e.g. not installed, corrupt audio the decoder can't touch).
    """
    logger.info("Falling back to local faster-whisper (%s) for %s", model_size, audio_path)
    try:
        model = _get_model(model_size)
        segments, info = model.transcribe(audio_path, beam_size=5)
        seg_list = []
        full_text_parts = []
        for seg in segments:
            seg_list.append(
                {"start": seg.start, "end": seg.end, "text": seg.text.strip()}
            )
            full_text_parts.append(seg.text.strip())

        return {
            "text": " ".join(full_text_parts).strip(),
            "segments": seg_list,
            "language": info.language,
            "provider": "local_fallback",
        }
    except STTAllProvidersExhaustedError:
        raise
    except Exception as e:
        raise STTAllProvidersExhaustedError(
            f"Local fallback ASR also failed: {e}"
        ) from e
