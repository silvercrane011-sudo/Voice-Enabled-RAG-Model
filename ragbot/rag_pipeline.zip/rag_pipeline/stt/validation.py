"""
Input validation for audio before it is sent to any STT provider.
Checks: file exists, extension allowed, size within free-tier-friendly bounds,
duration/sample rate readable via the `wave` stdlib module (falls back to a
soft-pass with a warning for compressed formats that stdlib can't inspect,
e.g. mp3/m4a — those get validated post-decode inside the provider module).
"""
import os
import wave
import contextlib
from dataclasses import dataclass
from typing import Optional

from config import CONFIG
from stt.errors import STTValidationError


@dataclass
class AudioMeta:
    path: str
    ext: str
    size_mb: float
    duration_seconds: Optional[float]
    sample_rate: Optional[int]
    inspected: bool  # True if we could actually read duration/sample_rate


def validate_audio_file(path: str) -> AudioMeta:
    cfg = CONFIG.stt

    if not os.path.isfile(path):
        raise STTValidationError(f"Audio file not found: {path}")

    ext = os.path.splitext(path)[1].lower()
    if ext not in cfg.allowed_formats:
        raise STTValidationError(
            f"Unsupported audio format '{ext}'. Allowed: {cfg.allowed_formats}"
        )

    size_bytes = os.path.getsize(path)
    size_mb = size_bytes / (1024 * 1024)
    if size_mb > cfg.max_file_size_mb:
        raise STTValidationError(
            f"Audio file too large: {size_mb:.2f}MB > {cfg.max_file_size_mb}MB limit"
        )
    if size_bytes == 0:
        raise STTValidationError("Audio file is empty (0 bytes)")

    duration = None
    sample_rate = None
    inspected = False

    if ext == ".wav":
        try:
            with contextlib.closing(wave.open(path, "rb")) as wf:
                frames = wf.getnframes()
                rate = wf.getframerate()
                duration = frames / float(rate) if rate else None
                sample_rate = rate
                inspected = True
        except wave.Error as e:
            raise STTValidationError(f"Corrupt or unreadable WAV file: {e}")

        if sample_rate is not None and sample_rate not in cfg.allowed_sample_rates:
            raise STTValidationError(
                f"Sample rate {sample_rate}Hz not in allowed set {cfg.allowed_sample_rates}"
            )
        if duration is not None:
            _validate_duration(duration, cfg)

    # Compressed formats (mp3/m4a/ogg/flac): stdlib `wave` can't read them.
    # We soft-pass here; the provider/fallback module re-checks duration
    # after decode and will raise STTValidationError there if out of bounds.

    return AudioMeta(
        path=path,
        ext=ext,
        size_mb=round(size_mb, 3),
        duration_seconds=duration,
        sample_rate=sample_rate,
        inspected=inspected,
    )


def _validate_duration(duration: float, cfg) -> None:
    if duration < cfg.min_duration_seconds:
        raise STTValidationError(
            f"Audio too short: {duration:.2f}s < {cfg.min_duration_seconds}s minimum"
        )
    if duration > cfg.max_duration_seconds:
        raise STTValidationError(
            f"Audio too long: {duration:.2f}s > {cfg.max_duration_seconds}s limit "
            f"(free-tier budget cap)"
        )
