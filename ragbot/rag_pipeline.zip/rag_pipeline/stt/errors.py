class STTError(Exception):
    """Base exception for all STT-related failures."""


class STTValidationError(STTError):
    """Raised when input audio fails validation (format, duration, size, sample rate)."""


class STTProviderError(STTError):
    """Raised when the remote STT provider call fails after retries."""


class STTAllProvidersExhaustedError(STTError):
    """Raised when the primary provider AND the local fallback both fail."""
