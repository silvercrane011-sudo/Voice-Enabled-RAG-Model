"""
Run this yourself, locally, with a real key set:

    export SARVAM_API_KEY=sk_...
    python stt/test_live_stt.py path/to/short_clip.wav

or for ElevenLabs:

    export ELEVENLABS_API_KEY=...
    python stt/test_live_stt.py path/to/short_clip.wav --provider elevenlabs

This could not be executed in the build sandbox this pipeline was assembled
in: both api.sarvam.ai/api.elevenlabs.io (cloud) and huggingface.co (needed
to download the faster-whisper local-fallback model on first use) are
unreachable from that sandbox's network allowlist. Every other module here
(chunking, retrieval, guardrails, harness) was actually executed and
verified; this one file is the exception -- run it once locally and you
have real proof STT requirement #1 works end-to-end, not just plausible code.
"""
import sys
import time
import argparse

sys.path.insert(0, ".")
from stt.provider import transcribe  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("audio_path")
    ap.add_argument("--provider", default=None, help="sarvam | elevenlabs (default: config default)")
    args = ap.parse_args()

    t0 = time.perf_counter()
    result = transcribe(args.audio_path, provider=args.provider)
    elapsed = (time.perf_counter() - t0) * 1000

    print(f"provider used : {result.provider}")
    print(f"language      : {result.language}")
    print(f"attempts      : {result.attempts}")
    print(f"stt latency ms: {result.latency_ms}")
    print(f"wall time ms  : {elapsed:.1f}")
    print(f"transcript    : {result.text}")


if __name__ == "__main__":
    main()
