"""
Benchmark harness (required deliverable): runs >=50 distinct test queries
through the full pipeline (retrieval -> guardrails -> rerank -> generation
-> post-guardrails), records per-stage latency for every single run (not
just a best-case sample), and reports P50/P70/P100 broken out by stage plus
an overall total. Writes a reproducible CSV alongside a printed table.
"""
import csv
import logging
import time
from typing import List, Dict, Any

from chunking.router import route_and_chunk
from indexing.hybrid_retriever import HybridRetriever
from orchestration.harness import RAGOrchestrator
from guardrails.pipeline import GuardrailPipeline
from benchmark.corpus import build_benchmark_corpus, build_benchmark_queries
from benchmark.percentiles import summarize_latencies

logging.getLogger().setLevel(logging.ERROR)  # keep benchmark output clean

STAGE_KEYS = ["retrieval_ms", "guardrails_pre_ms", "rerank_ms", "generation_ms", "guardrails_post_ms"]


def build_pipeline() -> RAGOrchestrator:
    retriever = HybridRetriever()
    corpus = build_benchmark_corpus()
    for source_id, text in corpus.items():
        retriever.index(route_and_chunk(text, source_id))
    guardrails = GuardrailPipeline()
    return RAGOrchestrator(
        retriever,
        guardrail_fn=guardrails.pre_generation_check,
        post_guardrail_fn=guardrails.post_generation_check,
    )


def run_benchmark(min_queries: int = 50, csv_path: str = "logs/benchmark_results.csv") -> Dict[str, Any]:
    orchestrator = build_pipeline()
    queries = [q for q in build_benchmark_queries(min_count=min_queries) if q.strip()]

    per_query_rows: List[Dict[str, Any]] = []
    stage_samples: Dict[str, List[float]] = {k: [] for k in STAGE_KEYS}
    total_samples: List[float] = []
    status_counts: Dict[str, int] = {}

    for i, query in enumerate(queries):
        result = orchestrator.answer(query)

        status_counts[result.status.value] = status_counts.get(result.status.value, 0) + 1
        total_samples.append(result.total_latency_ms)

        row = {
            "idx": i,
            "query": query,
            "status": result.status.value,
            "total_latency_ms": result.total_latency_ms,
        }
        for stage_key in STAGE_KEYS:
            val = result.stage_latencies_ms.get(stage_key, 0.0)
            stage_samples[stage_key].append(val)
            row[stage_key] = val
        per_query_rows.append(row)

    import os
    os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)
    with open(csv_path, "w", newline="") as f:
        fieldnames = ["idx", "query", "status", "total_latency_ms"] + STAGE_KEYS
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in per_query_rows:
            writer.writerow(row)

    report = {
        "num_queries": len(queries),
        "status_counts": status_counts,
        "total": summarize_latencies(total_samples),
        "by_stage": {k: summarize_latencies(v) for k, v in stage_samples.items()},
        "csv_path": csv_path,
        "cache_stats": orchestrator.retriever.cache_stats(),
        "strategy_hit_counts": orchestrator.retriever.strategy_hit_counts(),
    }
    return report


def print_report(report: Dict[str, Any]) -> None:
    print(f"\nBenchmark: {report['num_queries']} queries, status breakdown: {report['status_counts']}")
    print(f"Cache stats: {report['cache_stats']}")
    print(f"\n{'Stage':<20}{'P50 (ms)':>12}{'P70 (ms)':>12}{'P100 (ms)':>12}{'Mean (ms)':>12}{'N':>6}")
    print("-" * 74)

    def _row(name, stats):
        print(f"{name:<20}{stats['p50']:>12}{stats['p70']:>12}{stats['p100']:>12}{stats['mean']:>12}{stats['count']:>6}")

    for stage_key in STAGE_KEYS:
        _row(stage_key.replace("_ms", ""), report["by_stage"][stage_key])
    _row("TOTAL", report["total"])
    print(f"\nCSV written to: {report['csv_path']}")
    print(f"Strategy hit counts (which chunking strategy produced retrieved chunks): {report['strategy_hit_counts']}")


if __name__ == "__main__":
    report = run_benchmark(min_queries=50)
    print_report(report)
