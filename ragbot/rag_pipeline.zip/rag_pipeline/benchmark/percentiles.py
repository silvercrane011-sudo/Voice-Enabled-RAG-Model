"""
Percentile calculation for latency benchmarking. Uses linear interpolation
(same convention as numpy.percentile default) for P50/P70/P100.
"""
from typing import List, Dict
import math


def percentile(values: List[float], pct: float) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    if len(s) == 1:
        return s[0]
    k = (len(s) - 1) * (pct / 100.0)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return s[int(k)]
    d0 = s[int(f)] * (c - k)
    d1 = s[int(c)] * (k - f)
    return d0 + d1


def summarize_latencies(values: List[float]) -> Dict[str, float]:
    if not values:
        return {"p50": 0.0, "p70": 0.0, "p100": 0.0, "mean": 0.0, "count": 0}
    return {
        "p50": round(percentile(values, 50), 3),
        "p70": round(percentile(values, 70), 3),
        "p100": round(percentile(values, 100), 3),
        "mean": round(sum(values) / len(values), 3),
        "count": len(values),
    }
