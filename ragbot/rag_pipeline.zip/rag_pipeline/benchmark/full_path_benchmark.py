"""
Full-path benchmark (Part 8): the existing benchmark/run_benchmark.py only
measures retrieval -> guardrails -> rerank -> generation on an in-memory
index with local extractive generation. That's real, but it's not the
"chunking + vector DB retrieval + everything through to final output"
number the spec asks for, because it excludes two stages that dominate
real-world latency: STT and an actual LLM call.

This module adds those two stages on top of the existing harness instead
of duplicating it:
  1. STT stage: transcribes one short audio clip per query via
     stt.provider.transcribe() (real network call if a provider key is
     set; otherwise this stage is explicitly SKIPPED and the report says
     so, rather than silently reporting a partial number as if it were
     the full one).
  2. Generation stage: pass generate_fn=llm_generate_fn() to use a real
     LLM call (also real network, also explicitly flagged if no LLM_API_KEY
     is set) instead of the free local extractive stitcher.

Usage:
    # local-only path (default), same coverage as run_benchmark.py:
    python benchmark/full_path_benchmark.py

    # full path, once you have real keys set:
    export SARVAM_API_KEY=...
    export LLM_API_KEY=...
    python benchmark/full_path_benchmark.py --with-stt --with-llm --audio sample.wav
"""
import argparse
import csv
import os
import time
import logging
from typing import List, Dict, Any, Optional

from chunking.router import route_and_chunk
from indexing.hybrid_retriever import HybridRetriever
from orchestration.harness import RAGOrchestrator
from orchestration.steps import local_extractive_generate
from orchestration.llm_provider import call_llm_with_retry
from guardrails.pipeline import GuardrailPipeline
from stt.provider import transcribe
from stt.errors import STTAllProvidersExhaustedError, STTValidationError
from benchmark.corpus import build_benchmark_corpus, build_benchmark_queries
from benchmark.percentiles import summarize_latencies
from config import CONFIG

logging.getLogger().setLevel(logging.ERROR)

FULL_PATH_STAGE_KEYS = [
    "stt_ms", "retrieval_ms", "guardrails_pre_ms", "rerank_ms",
    "generation_ms", "guardrails_post_ms",
]


def build_orchestrator(use_llm: bool) -> RAGOrchestrator:
    retriever = HybridRetriever()
    corpus = build_benchmark_corpus()
    for source_id, text in corpus.items():
        retriever.index(route_and_chunk(text, source_id))
    guardrails = GuardrailPipeline()

    if use_llm:
        def generate_fn(query, chunks):
            context = "\n".join(f"[{c.chunk_id}] {c.text}" for c in chunks)
            prompt = (
                f"Answer the question using ONLY the context below. Cite chunk ids "
                f"in brackets for every claim.\n\nContext:\n{context}\n\nQuestion: {query}\nAnswer:"
            )
            try:
                return call_llm_with_retry(prompt)
            except Exception:
                return local_extractive_generate(query, chunks)  # graceful degrade, same as pipeline.py
    else:
        generate_fn = local_extractive_generate

    return RAGOrchestrator(
        retriever,
        generate_fn=generate_fn,
        guardrail_fn=guardrails.pre_generation_check,
        post_guardrail_fn=guardrails.post_generation_check,
    )


def _measure_stt(audio_path: Optional[str]) -> Optional[float]:
    """Returns latency in ms, or None if STT could not be exercised
    (no audio path given, or both cloud+local fallback failed)."""
    if not audio_path:
        return None
    t0 = time.perf_counter()
    try:
        transcribe(audio_path)
    except (STTAllProvidersExhaustedError, STTValidationError):
        return None
    return (time.perf_counter() - t0) * 1000


def run_full_path_benchmark(
    min_queries: int = 50,
    csv_path: str = "logs/full_path_benchmark_results.csv",
    audio_path: Optional[str] = None,
    use_llm: bool = False,
) -> Dict[str, Any]:
    orchestrator = build_orchestrator(use_llm)
    queries = [q for q in build_benchmark_queries(min_count=min_queries) if q.strip()]

    stt_attempted = audio_path is not None
    stt_actually_worked = False

    per_query_rows: List[Dict[str, Any]] = []
    stage_samples: Dict[str, List[float]] = {k: [] for k in FULL_PATH_STAGE_KEYS}
    full_total_samples: List[float] = []  # stt + everything else, only when stt succeeded
    local_total_samples: List[float] = []  # everything except stt, always populated
    status_counts: Dict[str, int] = {}

    for i, query in enumerate(queries):
        stt_ms = _measure_stt(audio_path)
        if stt_ms is not None:
            stt_actually_worked = True

        result = orchestrator.answer(query)
        status_counts[result.status.value] = status_counts.get(result.status.value, 0) + 1

        local_total_samples.append(result.total_latency_ms)
        if stt_ms is not None:
            full_total_samples.append(stt_ms + result.total_latency_ms)

        row = {
            "idx": i, "query": query, "status": result.status.value,
            "stt_ms": stt_ms if stt_ms is not None else "",
            "local_total_ms": result.total_latency_ms,
            "full_total_ms": (stt_ms + result.total_latency_ms) if stt_ms is not None else "",
        }
        stage_samples["stt_ms"].append(stt_ms if stt_ms is not None else 0.0)
        for stage_key in FULL_PATH_STAGE_KEYS[1:]:
            val = result.stage_latencies_ms.get(stage_key, 0.0)
            stage_samples[stage_key].append(val)
            row[stage_key] = val
        per_query_rows.append(row)

    os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)
    with open(csv_path, "w", newline="") as f:
        fieldnames = ["idx", "query", "status", "stt_ms", "local_total_ms", "full_total_ms"] + FULL_PATH_STAGE_KEYS[1:]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(per_query_rows)

    report = {
        "num_queries": len(queries),
        "status_counts": status_counts,
        "used_real_llm": use_llm,
        "stt_attempted": stt_attempted,
        "stt_actually_worked": stt_actually_worked,
        "local_path_total": summarize_latencies(local_total_samples),
        "full_path_total": summarize_latencies(full_total_samples) if full_total_samples else None,
        "by_stage": {k: summarize_latencies(v) for k, v in stage_samples.items()},
        "csv_path": csv_path,
    }
    return report


def print_report(report: Dict[str, Any]) -> None:
    print(f"\nFull-path benchmark: {report['num_queries']} queries, status: {report['status_counts']}")
    print(f"Real LLM generation used: {report['used_real_llm']}")

    if not report["stt_attempted"]:
        print("STT stage: SKIPPED (no --audio provided) — local_path_total below does NOT include STT.")
    elif not report["stt_actually_worked"]:
        print("STT stage: ATTEMPTED but failed on every query (no reachable provider) — "
              "local_path_total below does NOT include STT.")
    else:
        print("STT stage: measured successfully — see full_path_total for the true end-to-end number.")

    def _row(name, stats):
        print(f"{name:<20}{stats['p50']:>12}{stats['p70']:>12}{stats['p100']:>12}{stats['mean']:>12}{stats['count']:>6}")

    print(f"\n{'Stage':<20}{'P50 (ms)':>12}{'P70 (ms)':>12}{'P100 (ms)':>12}{'Mean (ms)':>12}{'N':>6}")
    print("-" * 74)
    for stage_key in FULL_PATH_STAGE_KEYS:
        _row(stage_key.replace("_ms", ""), report["by_stage"][stage_key])
    _row("LOCAL_PATH_TOTAL", report["local_path_total"])
    if report["full_path_total"]:
        _row("FULL_PATH_TOTAL", report["full_path_total"])
    print(f"\nCSV written to: {report['csv_path']}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-queries", type=int, default=50)
    ap.add_argument("--audio", default=None, help="Path to a short audio clip, reused per query to measure real STT latency")
    ap.add_argument("--with-llm", action="store_true", help="Use real LLM generation (requires LLM_API_KEY)")
    ap.add_argument("--csv", default="logs/full_path_benchmark_results.csv")
    args = ap.parse_args()

    report = run_full_path_benchmark(
        min_queries=args.min_queries, csv_path=args.csv,
        audio_path=args.audio, use_llm=args.with_llm,
    )
    print_report(report)
