"""
Builds a small but topically-varied local corpus and a set of 50+ distinct
test queries against it, so the benchmark harness measures realistic
retrieval+generation behavior rather than one best-case run.
"""
from typing import Dict, List

TOPICS = [
    ("stt", "Speech to text conversion uses Sarvam AI as the primary provider with a free tier, and falls back to a local faster-whisper model if the cloud call fails or the quota is exhausted. Input audio is validated for format, duration, and sample rate before any API call."),
    ("chunking", "Chunking strategies include fixed-size windows with overlap, semantic chunking based on embedding similarity breakpoints, structure-aware chunking that respects headers and speaker turns, and hierarchical parent-child chunking for expandable context."),
    ("retrieval", "Hybrid retrieval combines dense vector search using FAISS with sparse keyword search using BM25, fusing the two rankings with reciprocal rank fusion so that neither method's score scale dominates the other."),
    ("orchestration", "The orchestration harness uses Pydantic schemas for structured input and output at every stage, calls retrieval, reranking, and generation as distinct tool steps, and retries transient failures with exponential backoff."),
    ("guardrails", "Guardrails check whether a query is off topic using a similarity threshold, filter unsafe input with local rule-based patterns, and verify that generated answers are grounded in retrieved evidence before returning them to the user."),
    ("latency", "Latency optimization techniques include caching repeated query embeddings, running dense and sparse search concurrently on a thread pool, and capping the number of retrieved chunks to keep the critical path predictable."),
    ("vectordb", "FAISS and Chroma are free, open source, local vector databases with no hosted paid tier, storing chunk vectors alongside metadata so retrieval can filter by speaker, section, or time range."),
    ("transcripts", "Meeting transcripts are chunked by speaker turn, extracting timestamp ranges and speaker names as metadata so retrieval can filter conversations by who said what and when."),
]


def build_benchmark_corpus() -> Dict[str, str]:
    return {f"doc_{name}": text for name, text in TOPICS}


def build_benchmark_queries(min_count: int = 50) -> List[str]:
    """Generates >= min_count distinct queries spanning all topics, plus a
    handful of off-topic and edge-case queries so the benchmark reflects
    realistic guardrail behavior too, not just happy-path retrieval."""
    templates = [
        "What is {topic}?",
        "Explain how {topic} works.",
        "Why is {topic} important in this pipeline?",
        "Describe the design of {topic}.",
        "How does {topic} handle failures?",
        "What free tools are used for {topic}?",
        "Summarize the {topic} approach.",
    ]
    topic_names = {
        "stt": "speech to text",
        "chunking": "chunking strategy",
        "retrieval": "hybrid retrieval",
        "orchestration": "the orchestration harness",
        "guardrails": "guardrails",
        "latency": "latency optimization",
        "vectordb": "the vector database",
        "transcripts": "transcript chunking",
    }

    queries: List[str] = []
    for template in templates:
        for topic in topic_names.values():
            queries.append(template.format(topic=topic))

    # A few off-topic / edge-case queries to exercise guardrail refusal paths
    queries.extend([
        "What is the best pizza topping in Naples?",
        "Who won the last World Cup final?",
        "",  # will be filtered by caller if blank-testing isn't desired
        "asdkjaslkdj laksjdlkasjd",
    ])

    # dedupe while preserving order, then trim/pad to at least min_count
    seen = set()
    unique = []
    for q in queries:
        if q not in seen:
            seen.add(q)
            unique.append(q)

    if len(unique) < min_count:
        raise ValueError(f"Only generated {len(unique)} unique queries, need >= {min_count}")
    return unique
