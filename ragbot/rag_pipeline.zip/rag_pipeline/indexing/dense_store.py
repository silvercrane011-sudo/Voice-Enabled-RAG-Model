"""
Local, free dense vector store using FAISS (open-source, no hosted/paid tier).
Stores chunk metadata alongside vectors (in a parallel Python list) so
retrieval can filter by speaker/section/time-range/strategy before or after
the similarity search, as required.
"""
import logging
from typing import List, Optional, Dict, Any

import faiss
import numpy as np

from chunking.models import Chunk
from indexing.embeddings import embed_texts, embedding_dim

logger = logging.getLogger("indexing.dense_store")


class DenseVectorStore:
    def __init__(self, dim: Optional[int] = None):
        self.dim = dim or embedding_dim()
        # IndexFlatIP over L2-normalized vectors == cosine similarity search.
        # Flat index chosen deliberately: exact search, free, no training step
        # needed (unlike IVF/HNSW), fine at the scale of a RAG demo corpus and
        # keeps latency predictable for the <200ms budget (Part 7).
        self.index = faiss.IndexFlatIP(self.dim)
        self.chunks: List[Chunk] = []  # parallel array: index i <-> self.index vector i

    def add(self, chunks: List[Chunk]) -> None:
        if not chunks:
            return
        texts = [c.text for c in chunks]
        vectors = embed_texts(texts)
        vectors = self._normalize(vectors)
        self.index.add(vectors)
        self.chunks.extend(chunks)
        logger.info("Added %d chunks to dense store (total=%d)", len(chunks), len(self.chunks))

    @staticmethod
    def _normalize(vectors: np.ndarray) -> np.ndarray:
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return (vectors / norms).astype("float32")

    def search(
        self,
        query: str,
        top_k: int = 10,
        metadata_filter: Optional[Dict[str, Any]] = None,
        query_vector: Optional[np.ndarray] = None,
    ) -> List[tuple]:
        """Returns list of (Chunk, score) sorted by descending similarity.
        If metadata_filter is given, over-fetches then filters (post-filter),
        since FAISS flat index has no native metadata filtering.
        `query_vector` lets callers pass a pre-computed/cached embedding
        (Part 7 latency optimization) to skip re-embedding on repeated queries."""
        if self.index.ntotal == 0:
            return []

        if query_vector is None:
            query_vector = self._normalize(embed_texts([query]))
        fetch_k = top_k * 5 if metadata_filter else top_k
        fetch_k = min(fetch_k, self.index.ntotal)

        scores, indices = self.index.search(query_vector, fetch_k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            chunk = self.chunks[idx]
            if metadata_filter and not self._matches_filter(chunk, metadata_filter):
                continue
            results.append((chunk, float(score)))
            if len(results) >= top_k:
                break
        return results

    @staticmethod
    def _matches_filter(chunk: Chunk, metadata_filter: Dict[str, Any]) -> bool:
        for key, value in metadata_filter.items():
            if getattr(chunk.metadata, key, None) != value:
                return False
        return True
