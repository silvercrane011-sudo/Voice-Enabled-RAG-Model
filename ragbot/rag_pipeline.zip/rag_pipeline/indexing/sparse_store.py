"""
Local, free sparse keyword store using BM25 (rank_bm25 library, open-source,
pure Python, no hosted service). Complements the dense store for hybrid
retrieval (Part 4 combines both via reciprocal rank fusion).
"""
import re
import logging
from typing import List, Optional, Dict, Any

from rank_bm25 import BM25Okapi

from chunking.models import Chunk

logger = logging.getLogger("indexing.sparse_store")

_TOKEN_RE = re.compile(r"[A-Za-z0-9']+")


def _tokenize(text: str) -> List[str]:
    return [t.lower() for t in _TOKEN_RE.findall(text)]


class SparseKeywordStore:
    def __init__(self):
        self.chunks: List[Chunk] = []
        self._tokenized_corpus: List[List[str]] = []
        self._bm25: Optional[BM25Okapi] = None

    def add(self, chunks: List[Chunk]) -> None:
        if not chunks:
            return
        self.chunks.extend(chunks)
        self._tokenized_corpus.extend(_tokenize(c.text) for c in chunks)
        # BM25Okapi has no incremental-add API; rebuild index on add.
        # Fine for batch-indexing workflows; if streaming ingestion at scale
        # is needed, swap for a proper inverted-index engine (still free,
        # e.g. Whoosh) — noted as a scaling tradeoff in the write-up (Part 10).
        self._bm25 = BM25Okapi(self._tokenized_corpus)
        logger.info("Added %d chunks to sparse store (total=%d)", len(chunks), len(self.chunks))

    def search(
        self,
        query: str,
        top_k: int = 10,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> List[tuple]:
        """Returns list of (Chunk, score) sorted by descending BM25 score."""
        if self._bm25 is None or not self.chunks:
            return []

        query_tokens = _tokenize(query)
        scores = self._bm25.get_scores(query_tokens)

        ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
        results = []
        for idx in ranked:
            if scores[idx] <= 0:
                continue
            chunk = self.chunks[idx]
            if metadata_filter and not self._matches_filter(chunk, metadata_filter):
                continue
            results.append((chunk, float(scores[idx])))
            if len(results) >= top_k:
                break
        return results

    @staticmethod
    def _matches_filter(chunk: Chunk, metadata_filter: Dict[str, Any]) -> bool:
        for key, value in metadata_filter.items():
            if getattr(chunk.metadata, key, None) != value:
                return False
        return True
