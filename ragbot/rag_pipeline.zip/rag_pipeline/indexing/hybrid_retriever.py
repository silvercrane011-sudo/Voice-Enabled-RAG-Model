"""
Hybrid retrieval: combines DenseVectorStore (semantic/FAISS) and
SparseKeywordStore (BM25) results via Reciprocal Rank Fusion (RRF).

RRF chosen over raw weighted-score blending because dense cosine scores and
BM25 scores live on different, non-comparable scales — RRF sidesteps that by
fusing on *rank position* instead, which is a well-established, parameter-light
technique (Cormack et al. 2009) and doesn't require score normalization.

Also logs, per result, which chunking strategy (Part 2/3) produced the chunk
that was retrieved — required so we can evaluate which strategy performs
best over time (see benchmark module, Part 8).
"""
import logging
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

from chunking.models import Chunk
from indexing.dense_store import DenseVectorStore
from indexing.sparse_store import SparseKeywordStore
from indexing.embeddings import embed_texts
from orchestration.perf import QueryEmbeddingCache, run_parallel

logger = logging.getLogger("indexing.hybrid_retriever")


@dataclass
class RetrievalResult:
    chunk: Chunk
    rrf_score: float
    dense_rank: Optional[int]
    sparse_rank: Optional[int]
    chunk_strategy: str  # convenience alias of chunk.metadata.chunk_strategy


class HybridRetriever:
    def __init__(self, rrf_k: int = 60, use_query_cache: bool = True):
        # rrf_k=60 is the standard default from the original RRF paper;
        # higher k flattens the influence of top ranks, lower k sharpens it.
        self.dense = DenseVectorStore()
        self.sparse = SparseKeywordStore()
        self.rrf_k = rrf_k
        self._retrieval_log: List[Dict[str, Any]] = []
        self._query_cache = QueryEmbeddingCache() if use_query_cache else None

    def index(self, chunks: List[Chunk]) -> None:
        if not chunks:
            return
        self.dense.add(chunks)
        self.sparse.add(chunks)

    def search(
        self,
        query: str,
        top_k: int = 5,
        dense_k: int = 20,
        sparse_k: int = 20,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> List[RetrievalResult]:
        # Latency optimization (Part 7): cache the query embedding (exact-match
        # LRU) so repeated/session-local queries skip re-embedding, and run
        # dense + sparse search concurrently on a thread pool instead of
        # sequentially — both are independent, blocking, CPU-bound calls, so
        # overlapping them cuts wall-clock time roughly to max(dense, sparse)
        # instead of dense + sparse.
        if self._query_cache is not None:
            query_vector = self._query_cache.get_or_compute(
                query, lambda: self.dense._normalize(embed_texts([query]))
            )
        else:
            query_vector = None

        def _dense_call():
            return self.dense.search(query, top_k=dense_k, metadata_filter=metadata_filter, query_vector=query_vector)

        def _sparse_call():
            return self.sparse.search(query, top_k=sparse_k, metadata_filter=metadata_filter)

        dense_results, sparse_results = run_parallel(_dense_call, _sparse_call)

        dense_ranks = {chunk.chunk_id: rank for rank, (chunk, _) in enumerate(dense_results, start=1)}
        sparse_ranks = {chunk.chunk_id: rank for rank, (chunk, _) in enumerate(sparse_results, start=1)}

        chunk_by_id: Dict[str, Chunk] = {}
        for chunk, _ in dense_results:
            chunk_by_id[chunk.chunk_id] = chunk
        for chunk, _ in sparse_results:
            chunk_by_id[chunk.chunk_id] = chunk

        fused_scores: Dict[str, float] = {}
        for chunk_id in chunk_by_id:
            score = 0.0
            if chunk_id in dense_ranks:
                score += 1.0 / (self.rrf_k + dense_ranks[chunk_id])
            if chunk_id in sparse_ranks:
                score += 1.0 / (self.rrf_k + sparse_ranks[chunk_id])
            fused_scores[chunk_id] = score

        ranked_ids = sorted(fused_scores, key=lambda cid: fused_scores[cid], reverse=True)[:top_k]

        results = []
        for cid in ranked_ids:
            chunk = chunk_by_id[cid]
            result = RetrievalResult(
                chunk=chunk,
                rrf_score=fused_scores[cid],
                dense_rank=dense_ranks.get(cid),
                sparse_rank=sparse_ranks.get(cid),
                chunk_strategy=chunk.metadata.chunk_strategy,
            )
            results.append(result)
            self._log_retrieval(query, result)

        return results

    def _log_retrieval(self, query: str, result: "RetrievalResult") -> None:
        entry = {
            "query": query,
            "chunk_id": result.chunk.chunk_id,
            "source_id": result.chunk.metadata.source_id,
            "chunk_strategy": result.chunk_strategy,
            "rrf_score": round(result.rrf_score, 5),
            "dense_rank": result.dense_rank,
            "sparse_rank": result.sparse_rank,
        }
        self._retrieval_log.append(entry)
        logger.info("retrieval_log %s", entry)

    def get_retrieval_log(self) -> List[Dict[str, Any]]:
        return list(self._retrieval_log)

    def strategy_hit_counts(self) -> Dict[str, int]:
        """Aggregate: how many times each chunking strategy has produced a
        retrieved (i.e. actually useful) chunk — the evaluation signal
        required by the spec."""
        counts: Dict[str, int] = {}
        for entry in self._retrieval_log:
            s = entry["chunk_strategy"]
            counts[s] = counts.get(s, 0) + 1
        return counts

    def cache_stats(self) -> Dict[str, Any]:
        return self._query_cache.stats() if self._query_cache else {"caching": "disabled"}
