"""
Local, free embedding model wrapper used for the dense vector index.
Uses sentence-transformers/all-MiniLM-L6-v2 (same model as semantic chunking,
Part 2) so we don't load two different models into memory.

If sentence-transformers isn't installed, falls back to a deterministic
free hashing-based bag-of-words embedding (no external deps, no API key) so
the dense index still functions end-to-end in constrained environments —
retrieval quality is lower, but the pipeline degrades gracefully rather
than crashing, consistent with the fallback philosophy used in Part 1/2.
"""
import hashlib
import logging
from typing import List

import numpy as np

logger = logging.getLogger("indexing.embeddings")

_MODEL_CACHE = {}
_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
FALLBACK_DIM = 384  # matches MiniLM's real output dim, so index code is dim-agnostic


def _get_model():
    if _MODEL_NAME in _MODEL_CACHE:
        return _MODEL_CACHE[_MODEL_NAME]
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer(_MODEL_NAME)
    _MODEL_CACHE[_MODEL_NAME] = model
    return model


def _hashing_fallback_embed(texts: List[str], dim: int = FALLBACK_DIM) -> np.ndarray:
    """Deterministic, dependency-free embedding: hashes token n-grams into a
    fixed-size vector and L2-normalizes. Not semantically strong, but keeps
    hybrid retrieval (dense+sparse) functional with zero paid/heavy deps."""
    vectors = np.zeros((len(texts), dim), dtype="float32")
    for i, text in enumerate(texts):
        for tok in text.lower().split():
            h = int(hashlib.md5(tok.encode("utf-8")).hexdigest(), 16)
            idx = h % dim
            vectors[i, idx] += 1.0
        norm = np.linalg.norm(vectors[i])
        if norm > 0:
            vectors[i] /= norm
    return vectors


def embed_texts(texts: List[str]) -> np.ndarray:
    if not texts:
        return np.zeros((0, FALLBACK_DIM), dtype="float32")
    try:
        model = _get_model()
        emb = model.encode(texts, show_progress_bar=False, convert_to_numpy=True)
        return emb.astype("float32")
    except ImportError:
        logger.warning(
            "sentence-transformers not installed; using hashing fallback embeddings "
            "(install with: pip install sentence-transformers --break-system-packages)"
        )
        return _hashing_fallback_embed(texts)


def embedding_dim() -> int:
    try:
        model = _get_model()
        return model.get_sentence_embedding_dimension()
    except ImportError:
        return FALLBACK_DIM
