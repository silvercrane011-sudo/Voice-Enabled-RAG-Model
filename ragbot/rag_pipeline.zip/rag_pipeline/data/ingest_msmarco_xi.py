"""
Ingest a MSMARCO-XI JSONL export (produced by data/load_msmarco_xi.py) into
the VoiceRAGPipeline, replacing the old synthetic 8-doc placeholder corpus.

Each passage is ingested as its own document via ingest_text() -> the
chunking router still applies (a passage may itself get split further if
long), and per-passage metadata (source_query, reference_answers, lang) is
preserved on the JSONL line for later eval, even though the current
chunk schema does not yet carry it through to the index (see note below).

Usage:
    python data/ingest_msmarco_xi.py --in data/msmarco_xi_hi.jsonl --pipeline-out data/corpus_stats.json
"""
import argparse
import json
import time
import sys

sys.path.insert(0, ".")
from pipeline import VoiceRAGPipeline  # noqa: E402


def ingest_jsonl(pipe: VoiceRAGPipeline, path: str, limit: int = 0) -> dict:
    n_docs = 0
    n_chunks = 0
    t0 = time.perf_counter()

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if limit and n_docs >= limit:
                break
            line = line.strip()
            if not line:
                continue
            record = json.loads(line)
            text = record["text"]
            if len(text.strip()) < 20:
                continue  # skip near-empty passages, not worth indexing
            n_chunks += pipe.ingest_text(text, source_id=record["doc_id"])
            n_docs += 1

    elapsed = time.perf_counter() - t0
    return {
        "docs_ingested": n_docs,
        "chunks_indexed": n_chunks,
        "ingest_time_s": round(elapsed, 3),
        "source_file": path,
    }


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path", required=True)
    ap.add_argument("--limit", type=int, default=0, help="Cap number of passages (0 = all)")
    ap.add_argument("--pipeline-out", default=None, help="Write ingestion stats JSON here")
    args = ap.parse_args()

    pipe = VoiceRAGPipeline()
    stats = ingest_jsonl(pipe, args.in_path, args.limit)
    print(json.dumps(stats, indent=2))

    if args.pipeline_out:
        with open(args.pipeline_out, "w") as f:
            json.dump(stats, f, indent=2)
