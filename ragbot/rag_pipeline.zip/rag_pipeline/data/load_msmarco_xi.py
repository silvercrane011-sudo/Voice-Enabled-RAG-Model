"""
Loader for ai4bharat/MSMARCO-XI (IndicMSMARCO).

NOTE: huggingface.co is unreachable from the build sandbox this pipeline
was assembled in — this script is written against the dataset's confirmed
schema but has not been executed end-to-end here. Run it in an environment
with normal internet access (`pip install datasets` first).

Schema per row: {"query": str, "answers": list[str], "passages": list[dict]}
Each passage dict follows MS MARCO convention: passage_text, url, is_selected.

Usage:
    python data/load_msmarco_xi.py --lang hi --limit 300 --out data/msmarco_xi_hi.jsonl
"""
import argparse
import json
import sys


def load_and_export(lang: str, split: str, limit: int, out_path: str) -> int:
    try:
        from datasets import load_dataset
    except ImportError:
        print("Missing dependency: pip install datasets --break-system-packages", file=sys.stderr)
        sys.exit(1)

    ds = load_dataset("ai4bharat/MSMARCO-XI", lang, split=split)

    n_written = 0
    with open(out_path, "w", encoding="utf-8") as f:
        for i, row in enumerate(ds):
            if limit and n_written >= limit:
                break
            query = row.get("query", "")
            answers = row.get("answers", [])
            passages = row.get("passages", [])

            for p_idx, p in enumerate(passages):
                # passage_text is the retrievable unit; keep query/answers as
                # metadata so we can later build a query-relevance eval set.
                text = p.get("passage_text") if isinstance(p, dict) else p
                if not text:
                    continue
                record = {
                    "doc_id": f"msmarco-xi-{lang}-{i}-{p_idx}",
                    "text": text,
                    "lang": lang,
                    "source_query": query,
                    "reference_answers": answers,
                    "is_selected": p.get("is_selected") if isinstance(p, dict) else None,
                }
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
                n_written += 1

    return n_written


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--lang", default="hi", help="Language config, e.g. hi, ta, te, bn")
    ap.add_argument("--split", default="train")
    ap.add_argument("--limit", type=int, default=300, help="Max passages to export (0 = all)")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    out_path = args.out or f"data/msmarco_xi_{args.lang}.jsonl"
    count = load_and_export(args.lang, args.split, args.limit, out_path)
    print(f"Wrote {count} passages from ai4bharat/MSMARCO-XI [{args.lang}/{args.split}] -> {out_path}")
