"""
Strategy 4 (optional but preferred): Hierarchical parent/child chunking.

Builds two layers over the same source text:
  - Parent chunks: large context windows (e.g. 800 tokens)
  - Child chunks: small precise windows (e.g. 200 tokens) that live inside
    each parent, with `parent_chunk_id` set so retrieval can fetch a tight
    child match but expand to the parent's full context at answer time.

Reuses fixed_size_chunk's tokenizer utilities to stay consistent with
Strategy 1 and avoid duplicating tokenization logic.
"""
from typing import List, Tuple

from chunking.models import Chunk, new_chunk
from chunking.fixed_size import _tokenize, _detokenize


def hierarchical_chunk(
    text: str,
    source_id: str,
    parent_window_tokens: int = 800,
    parent_overlap_ratio: float = 0.1,
    child_window_tokens: int = 200,
    child_overlap_ratio: float = 0.15,
) -> Tuple[List[Chunk], List[Chunk]]:
    """Returns (parent_chunks, child_chunks). Both lists should be indexed/stored;
    retrieval searches child_chunks and resolves parent via parent_chunk_id."""
    if not text or not text.strip():
        return [], []

    tokens = _tokenize(text)
    n = len(tokens)
    parent_stride = max(1, int(parent_window_tokens * (1 - parent_overlap_ratio)))

    parents: List[Chunk] = []
    children: List[Chunk] = []

    parent_position = 0
    i = 0
    while i < n:
        parent_tokens = tokens[i : i + parent_window_tokens]
        parent_text = _detokenize(parent_tokens).strip()
        if not parent_text:
            break

        parent_chunk = new_chunk(
            parent_text,
            source_id,
            parent_position,
            strategy="hierarchical_parent",
        )
        parents.append(parent_chunk)

        # child chunks live entirely within this parent's token window
        child_stride = max(1, int(child_window_tokens * (1 - child_overlap_ratio)))
        j = 0
        child_position = 0
        m = len(parent_tokens)
        while j < m:
            child_tokens = parent_tokens[j : j + child_window_tokens]
            child_text = _detokenize(child_tokens).strip()
            if child_text:
                child_chunk = new_chunk(
                    child_text,
                    source_id,
                    child_position,
                    strategy="hierarchical_child",
                    parent_chunk_id=parent_chunk.chunk_id,
                )
                children.append(child_chunk)
                child_position += 1
            if j + child_window_tokens >= m:
                break
            j += child_stride

        parent_position += 1
        if i + parent_window_tokens >= n:
            break
        i += parent_stride

    return parents, children
