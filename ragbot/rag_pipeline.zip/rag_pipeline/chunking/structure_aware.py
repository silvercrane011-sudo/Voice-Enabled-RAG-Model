"""
Strategy 3: Structure/metadata-aware chunking.

Respects document structure instead of blindly windowing text:
  - Markdown-style headers (#, ##, ###) -> section_title metadata
  - Speaker-turn transcripts ("Speaker: text" or "[00:12] Speaker: text") ->
    speaker + timestamp_range metadata
  - Paragraph boundaries (blank lines) as the default split unit

Each chunk carries as much metadata as the source format allows, so
downstream retrieval can filter by speaker/section/time range (Part 4).
"""
import re
from typing import List, Optional, Tuple

from chunking.models import Chunk, new_chunk

_HEADER_RE = re.compile(r"^(#{1,6})\s+(.*)$")
# matches "[00:12] Alice: hello" or "Alice: hello" or "00:12:05 - Alice: hello"
_SPEAKER_TURN_RE = re.compile(
    r"^(?:\[?(?P<ts>\d{1,2}:\d{2}(?::\d{2})?)\]?\s*[-–]?\s*)?"
    r"(?P<speaker>[A-Za-z][A-Za-z0-9 _.'-]{0,40}):\s*(?P<text>.+)$"
)


def _looks_like_transcript(lines: List[str]) -> bool:
    hits = sum(1 for l in lines if _SPEAKER_TURN_RE.match(l.strip()))
    return hits >= max(2, len(lines) // 4)  # at least a quarter of lines match


def _chunk_transcript(lines: List[str], source_id: str) -> List[Chunk]:
    chunks = []
    position = 0
    for line in lines:
        line = line.strip()
        if not line:
            continue
        m = _SPEAKER_TURN_RE.match(line)
        if not m:
            # non-matching line (e.g. stage direction) — attach as own chunk, no speaker
            chunks.append(
                new_chunk(line, source_id, position, strategy="structure")
            )
            position += 1
            continue
        ts = m.group("ts")
        speaker = m.group("speaker").strip()
        text = m.group("text").strip()
        chunks.append(
            new_chunk(
                text,
                source_id,
                position,
                strategy="structure",
                speaker=speaker,
                timestamp_range=ts,
            )
        )
        position += 1
    return chunks


def _chunk_markdown(text: str, source_id: str) -> List[Chunk]:
    lines = text.split("\n")
    chunks = []
    position = 0
    current_title: Optional[str] = None
    buffer: List[str] = []

    def flush():
        nonlocal position, buffer
        content = "\n".join(buffer).strip()
        if content:
            chunks.append(
                new_chunk(
                    content,
                    source_id,
                    position,
                    strategy="structure",
                    section_title=current_title,
                )
            )
            position += 1
        buffer = []

    for line in lines:
        header_match = _HEADER_RE.match(line.strip())
        if header_match:
            flush()
            current_title = header_match.group(2).strip()
            continue
        if line.strip() == "":
            # paragraph boundary: flush if we already have content buffered
            if buffer:
                flush()
            continue
        buffer.append(line)
    flush()
    return chunks


def structure_aware_chunk(text: str, source_id: str) -> List[Chunk]:
    if not text or not text.strip():
        return []

    lines = [l for l in text.split("\n") if l.strip()]

    if _looks_like_transcript(lines):
        return _chunk_transcript(lines, source_id)

    if any(_HEADER_RE.match(l.strip()) for l in lines):
        return _chunk_markdown(text, source_id)

    # default: paragraph-boundary chunking, no headers/speakers detected
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks = []
    for i, p in enumerate(paragraphs):
        chunks.append(new_chunk(p, source_id, i, strategy="structure"))
    return chunks
