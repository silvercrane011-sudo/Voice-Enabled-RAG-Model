"""
Strategy 1: Fixed-size chunking with overlap (baseline).

Token-window based (falls back to whitespace-token approximation if no
tokenizer is available — keeps this dependency-free/local/free).
Default: 400 tokens / 15% overlap, both configurable.
"""
from typing import List

from chunking.models import Chunk, new_chunk

try:
    import tiktoken
    _ENC = tiktoken.get_encoding("cl100k_base")

    def _tokenize(text: str) -> List[str]:
        return [str(t) for t in _ENC.encode(text)]

    def _detokenize(tokens: List[str]) -> str:
        return _ENC.decode([int(t) for t in tokens])

    _HAS_TIKTOKEN = True
except ImportError:
    _HAS_TIKTOKEN = False

    def _tokenize(text: str) -> List[str]:
        # whitespace-approximation fallback, fully free/local, no deps
        return text.split()

    def _detokenize(tokens: List[str]) -> str:
        return " ".join(tokens)


def fixed_size_chunk(
    text: str,
    source_id: str,
    window_tokens: int = 400,
    overlap_ratio: float = 0.15,
) -> List[Chunk]:
    if not text or not text.strip():
        return []
    if window_tokens <= 0:
        raise ValueError("window_tokens must be > 0")
    if not (0 <= overlap_ratio < 1):
        raise ValueError("overlap_ratio must be in [0, 1)")

    tokens = _tokenize(text)
    stride = max(1, int(window_tokens * (1 - overlap_ratio)))

    chunks = []
    position = 0
    i = 0
    n = len(tokens)
    while i < n:
        window = tokens[i : i + window_tokens]
        chunk_text = _detokenize(window).strip()
        if chunk_text:
            chunks.append(
                new_chunk(
                    text=chunk_text,
                    source_id=source_id,
                    position=position,
                    strategy="fixed",
                )
            )
            position += 1
        if i + window_tokens >= n:
            break
        i += stride

    return chunks
