"""
Strategy 2: Semantic chunking.

Splits text into sentences, embeds each with a free local model
(sentence-transformers/all-MiniLM-L6-v2 — 22MB, CPU-friendly, no API key),
then merges consecutive sentences into a chunk until the cosine distance
between sentence embeddings crosses a breakpoint threshold (a big topic
shift), starting a new chunk there.

Falls back to a simple sentence-length heuristic if sentence-transformers
isn't installed, so the pipeline never hard-crashes on a missing optional dep.
"""
import re
import logging
from typing import List

import numpy as np

from chunking.models import Chunk, new_chunk

logger = logging.getLogger("chunking.semantic")

_MODEL_CACHE = {}
_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"


def _split_sentences(text: str) -> List[str]:
    # Lightweight, dependency-free sentence splitter (good enough for chunking
    # purposes; not meant to be a full NLP sentence tokenizer).
    text = text.strip()
    if not text:
        return []
    parts = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9\"'])", text)
    return [p.strip() for p in parts if p.strip()]


def _get_model():
    if _MODEL_NAME in _MODEL_CACHE:
        return _MODEL_CACHE[_MODEL_NAME]
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer(_MODEL_NAME)
    _MODEL_CACHE[_MODEL_NAME] = model
    return model


def _cosine_distance(a: np.ndarray, b: np.ndarray) -> float:
    denom = (np.linalg.norm(a) * np.linalg.norm(b))
    if denom == 0:
        return 1.0
    sim = float(np.dot(a, b) / denom)
    return 1.0 - sim


def semantic_chunk(
    text: str,
    source_id: str,
    breakpoint_percentile: float = 90.0,
    min_sentences_per_chunk: int = 1,
    max_chunk_chars: int = 2000,
) -> List[Chunk]:
    sentences = _split_sentences(text)
    if not sentences:
        return []
    if len(sentences) == 1:
        return [new_chunk(sentences[0], source_id, 0, strategy="semantic")]

    try:
        model = _get_model()
        embeddings = model.encode(sentences, show_progress_bar=False)
        distances = [
            _cosine_distance(embeddings[i], embeddings[i + 1])
            for i in range(len(embeddings) - 1)
        ]
        threshold = float(np.percentile(distances, breakpoint_percentile))
        breakpoints = {i for i, d in enumerate(distances) if d > threshold}
    except ImportError:
        logger.warning(
            "sentence-transformers not installed; falling back to length-heuristic "
            "semantic chunking (install with: pip install sentence-transformers "
            "--break-system-packages)"
        )
        breakpoints = _fallback_breakpoints(sentences, max_chunk_chars)

    chunks = []
    position = 0
    buffer: List[str] = []
    buffer_chars = 0

    for idx, sent in enumerate(sentences):
        buffer.append(sent)
        buffer_chars += len(sent)
        is_breakpoint = idx in breakpoints
        is_last = idx == len(sentences) - 1
        over_length = buffer_chars >= max_chunk_chars

        if (is_breakpoint and len(buffer) >= min_sentences_per_chunk) or is_last or over_length:
            chunk_text = " ".join(buffer).strip()
            if chunk_text:
                chunks.append(
                    new_chunk(chunk_text, source_id, position, strategy="semantic")
                )
                position += 1
            buffer = []
            buffer_chars = 0

    return chunks


def _fallback_breakpoints(sentences: List[str], max_chunk_chars: int) -> set:
    """No-embedding-model fallback: break every time accumulated length
    would exceed max_chunk_chars. Deterministic, free, dependency-free."""
    breakpoints = set()
    running = 0
    for i, s in enumerate(sentences):
        running += len(s)
        if running >= max_chunk_chars:
            breakpoints.add(i)
            running = 0
    return breakpoints
