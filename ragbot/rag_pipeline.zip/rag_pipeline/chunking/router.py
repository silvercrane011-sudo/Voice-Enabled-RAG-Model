"""
Chunking strategy router.

Picks the appropriate chunking strategy(ies) based on a document's declared
type (or auto-detects if not given), runs it, and returns a unified list of
Chunks with `chunk_strategy` set on each — so downstream retrieval can log
which strategy produced the chunk that was ultimately retrieved (required
for strategy evaluation over time, see indexing/retrieval module in Part 4).
"""
import re
import logging
from enum import Enum
from typing import List, Optional

from chunking.models import Chunk
from chunking.fixed_size import fixed_size_chunk
from chunking.semantic import semantic_chunk
from chunking.structure_aware import structure_aware_chunk, _looks_like_transcript, _HEADER_RE
from chunking.hierarchical import hierarchical_chunk

logger = logging.getLogger("chunking.router")


class DocType(str, Enum):
    TRANSCRIPT = "transcript"          # speaker-turn voice/meeting transcripts
    STRUCTURED_DOC = "structured_doc"  # markdown/headers present
    PLAIN_TEXT = "plain_text"          # prose, no structure
    LONG_DOC = "long_doc"              # long enough to benefit from hierarchical


LONG_DOC_TOKEN_THRESHOLD = 1500


def detect_doc_type(text: str) -> DocType:
    lines = [l for l in text.split("\n") if l.strip()]
    if not lines:
        return DocType.PLAIN_TEXT

    if _looks_like_transcript(lines):
        return DocType.TRANSCRIPT
    if any(_HEADER_RE.match(l.strip()) for l in lines):
        return DocType.STRUCTURED_DOC
    if len(text.split()) > LONG_DOC_TOKEN_THRESHOLD:
        return DocType.LONG_DOC
    return DocType.PLAIN_TEXT


def route_and_chunk(
    text: str,
    source_id: str,
    doc_type: Optional[DocType] = None,
    use_semantic_for_plain: bool = True,
) -> List[Chunk]:
    """
    Routing table:
      TRANSCRIPT        -> structure-aware (speaker/timestamp metadata is essential)
      STRUCTURED_DOC     -> structure-aware (respects headers/sections)
      LONG_DOC           -> hierarchical (parent/child; children are the retrievable units)
      PLAIN_TEXT         -> semantic chunking (falls back to fixed-size if no embedding model)
    Every chunk returned carries `chunk_strategy` metadata regardless of path,
    so retrieval-time logging (Part 4) can attribute results to a strategy.
    """
    if not text or not text.strip():
        return []

    resolved_type = doc_type or detect_doc_type(text)
    logger.info("Routing source_id=%s to strategy for doc_type=%s", source_id, resolved_type)

    if resolved_type == DocType.TRANSCRIPT:
        return structure_aware_chunk(text, source_id)

    if resolved_type == DocType.STRUCTURED_DOC:
        return structure_aware_chunk(text, source_id)

    if resolved_type == DocType.LONG_DOC:
        parents, children = hierarchical_chunk(text, source_id)
        # index both layers; children are marked as the primary retrievable
        # unit via strategy name, parents are looked up by parent_chunk_id
        return parents + children

    # PLAIN_TEXT
    if use_semantic_for_plain:
        try:
            chunks = semantic_chunk(text, source_id)
            if chunks:
                return chunks
        except Exception as e:
            logger.warning("Semantic chunking failed (%s), falling back to fixed-size", e)

    return fixed_size_chunk(text, source_id)


def chunk_with_all_strategies(text: str, source_id: str) -> dict:
    """
    Utility for offline strategy evaluation (feeds the 'log which strategy
    performs best over time' requirement): runs every strategy on the same
    text and returns all results keyed by strategy name, for A/B comparison
    in the benchmark harness (Part 8).
    """
    parents, children = hierarchical_chunk(text, source_id)
    return {
        "fixed": fixed_size_chunk(text, source_id),
        "semantic": semantic_chunk(text, source_id),
        "structure": structure_aware_chunk(text, source_id),
        "hierarchical_parent": parents,
        "hierarchical_child": children,
    }
