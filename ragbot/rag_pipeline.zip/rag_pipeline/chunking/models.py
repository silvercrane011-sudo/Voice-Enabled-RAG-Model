"""
Shared chunk data model used by every chunking strategy (Parts 2 & 3) and
consumed downstream by indexing (Part 4).
"""
from dataclasses import dataclass, field
from typing import Optional, List
import hashlib


@dataclass
class ChunkMetadata:
    source_id: str
    position: int                      # ordinal position within source doc
    timestamp_range: Optional[str] = None   # e.g. "12.3-18.7" for transcripts
    speaker: Optional[str] = None
    section_title: Optional[str] = None
    chunk_strategy: str = "unknown"    # "fixed", "semantic", "structure", "hierarchical"
    parent_chunk_id: Optional[str] = None   # set by hierarchical strategy


@dataclass
class Chunk:
    text: str
    metadata: ChunkMetadata
    chunk_id: str = field(default="")

    def __post_init__(self):
        if not self.chunk_id:
            raw = f"{self.metadata.source_id}:{self.metadata.position}:{self.text[:50]}"
            self.chunk_id = hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


def new_chunk(text: str, source_id: str, position: int, strategy: str, **meta_kwargs) -> Chunk:
    md = ChunkMetadata(
        source_id=source_id,
        position=position,
        chunk_strategy=strategy,
        **meta_kwargs,
    )
    return Chunk(text=text, metadata=md)
