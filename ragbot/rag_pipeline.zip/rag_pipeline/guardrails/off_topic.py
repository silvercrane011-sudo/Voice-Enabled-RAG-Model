"""
Off-topic detection: rejects/redirects queries unrelated to the indexed
dataset.

v1 used only the RRF top score against a fixed threshold. Root cause of
the bug this fixes: RRF fuses on *rank*, not absolute relevance — with
any corpus (especially a small one), the sparse/dense stores will always
return SOME best-ranked chunk for any query, even a completely unrelated
one, so a pure-RRF top score stays inside the same tight numeric band
regardless of whether the query is actually related to the corpus. That's
why "What is the capital of France?" against an 8-doc corpus previously
scored as on-topic — rank-1-of-something isn't evidence of relevance.

v2 adds a second, independent, absolute signal: lexical word-overlap
between the query and the top chunk's actual text (same primitive
already used post-generation by guardrails/groundedness.py, reused here
for consistency and because it needs no extra dependency). A query is
on-topic only if BOTH the RRF rank signal AND the lexical overlap floor
are satisfied — rank alone is necessary but not sufficient.
"""
from orchestration.schemas import RetrievalOutput, GuardrailVerdict
from guardrails.groundedness import _tokenize

# Common function words excluded from the overlap check below — without
# this, short queries like "What is the capital of France?" trivially
# "overlap" with almost any English corpus via words like is/the/of,
# making the overlap signal meaningless. This was caught by testing
# against a real off-topic query, not assumed upfront.
_STOPWORDS = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "what", "which", "who", "whom", "this", "that", "these", "those",
    "of", "in", "on", "at", "to", "for", "with", "by", "about", "as",
    "and", "or", "but", "if", "so", "do", "does", "did", "can", "could",
    "will", "would", "should", "i", "you", "he", "she", "it", "we", "they",
    "my", "your", "his", "her", "its", "our", "their", "me", "him", "us",
    "them", "how", "when", "where", "why", "not", "no", "yes", "there",
})

# RRF scores with rrf_k=60 and two source lists (dense+sparse) top out around
# 2/(60+1) ≈ 0.033 for a rank-1-in-both hit. Kept as a floor (necessary
# condition) but no longer the only signal — see module docstring.
DEFAULT_MIN_TOP_SCORE = 0.008

# Word-overlap ratio (shared vocabulary / query vocabulary) between the
# query and the single best-matching chunk. Deliberately lower than the
# post-generation groundedness threshold (0.15) since queries are short
# and won't share as many words with a passage as a full generated answer
# will — this is a coarse "is there ANY real lexical connection" check,
# not a precision check.
DEFAULT_MIN_QUERY_OVERLAP = 0.08


def _stem(word: str) -> str:
    """Minimal, dependency-free suffix-stripping so word-form variants
    ("transcript"/"transcripts", "chunking"/"chunked") still count as
    overlap. Not a real stemmer (no Porter/Snowball dependency by design,
    staying consistent with this filter's free/local/no-extra-deps
    constraint) — good enough to catch plurals and common verb endings,
    which is what real queries actually hit in practice."""
    for suffix in ("ing", "ed", "es", "s"):
        if word.endswith(suffix) and len(word) > len(suffix) + 2:
            return word[: -len(suffix)]
    return word


def _query_overlap_ratio(query: str, chunk_text: str) -> float:
    query_words = {_stem(w) for w in (_tokenize(query) - _STOPWORDS)}
    if not query_words:
        return 0.0
    chunk_words = {_stem(w) for w in (_tokenize(chunk_text) - _STOPWORDS)}
    shared = query_words & chunk_words
    return len(shared) / len(query_words)


def check_off_topic(
    retrieval_output: RetrievalOutput,
    min_top_score: float = DEFAULT_MIN_TOP_SCORE,
    min_query_overlap: float = DEFAULT_MIN_QUERY_OVERLAP,
    top_n_considered: int = 3,
) -> GuardrailVerdict:
    if not retrieval_output.chunks:
        return GuardrailVerdict(
            check_name="off_topic",
            passed=False,
            reason="No chunks retrieved — query appears unrelated to indexed corpus.",
            score=0.0,
        )

    # Consider the top few ranked chunks, not just the single highest-scored
    # one: with small corpora, RRF scores tie often (e.g. two chunks both
    # rank-1-in-one-list), and a naive single-max pick breaks ties
    # arbitrarily — this previously caused a real on-topic query to be
    # refused because the tie-break happened to land on an unrelated
    # chunk instead of the actually-relevant one that shared the same
    # score. Passing if ANY of the top few candidates clears both floors
    # is more robust to that tie noise.
    candidates = sorted(retrieval_output.chunks, key=lambda c: c.rrf_score, reverse=True)[:top_n_considered]

    best = None  # (top_score, overlap) of the best-passing or best-overall candidate
    for chunk in candidates:
        top_score = chunk.rrf_score
        overlap = _query_overlap_ratio(retrieval_output.query, chunk.text)
        rank_ok = top_score >= min_top_score
        overlap_ok = overlap >= min_query_overlap
        if rank_ok and overlap_ok:
            best = (top_score, overlap)
            break
        if best is None or overlap > best[1]:
            best = (top_score, overlap)

    top_score, overlap = best
    rank_ok = top_score >= min_top_score
    overlap_ok = overlap >= min_query_overlap
    passed = rank_ok and overlap_ok

    if passed:
        reason = (
            f"Top retrieval score {top_score:.5f} and query/chunk word-overlap "
            f"{overlap:.2f} both meet on-topic thresholds (best of top {top_n_considered} candidates)."
        )
    elif not overlap_ok:
        reason = (
            f"Best query/chunk word-overlap among top {top_n_considered} candidates is {overlap:.2f}, "
            f"below on-topic threshold {min_query_overlap} — none of the highest-ranked chunks share "
            f"meaningful vocabulary with the query. Query likely unrelated to indexed dataset."
        )
    else:
        reason = (
            f"Top retrieval score {top_score:.5f} below on-topic threshold "
            f"{min_top_score} — query likely unrelated to indexed dataset."
        )

    combined_score = (max(top_score, 0.0) * overlap) ** 0.5
    return GuardrailVerdict(check_name="off_topic", passed=passed, reason=reason, score=round(combined_score, 5))
