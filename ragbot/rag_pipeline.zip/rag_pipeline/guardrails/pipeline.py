"""
Combined guardrail pipeline: wires off-topic + unsafe-input checks into the
PRE-generation gate (matches `guardrail_fn` signature expected by
RAGOrchestrator, Part 5), and exposes a separate POST-generation groundedness
gate the harness calls after generation_step.

Every verdict (pass/fail/reason) is appended to an audit log for full
auditability, per spec.
"""
import logging
from typing import List, Optional

from orchestration.schemas import QueryRequest, RetrievalOutput, GuardrailReport, GuardrailVerdict
from orchestration.utils import StructuredLogger
from guardrails.off_topic import check_off_topic, DEFAULT_MIN_TOP_SCORE
from guardrails.safety_filter import check_unsafe_input
from guardrails.groundedness import check_groundedness, DEFAULT_MIN_OVERLAP_RATIO

logger = logging.getLogger("guardrails.pipeline")


class GuardrailPipeline:
    def __init__(
        self,
        min_top_score: float = DEFAULT_MIN_TOP_SCORE,
        min_overlap_ratio: float = DEFAULT_MIN_OVERLAP_RATIO,
        audit_logger: Optional[StructuredLogger] = None,
    ):
        self.min_top_score = min_top_score
        self.min_overlap_ratio = min_overlap_ratio
        self.audit_logger = audit_logger or StructuredLogger(path="logs/guardrail_audit.jsonl")

    def pre_generation_check(self, query_request: QueryRequest, retrieval_output: RetrievalOutput) -> GuardrailReport:
        """Matches the `guardrail_fn(query_request, retrieval_output) -> GuardrailReport`
        signature RAGOrchestrator expects — pass this bound method directly."""
        verdicts: List[GuardrailVerdict] = [
            check_unsafe_input(query_request.text),
            check_off_topic(retrieval_output, min_top_score=self.min_top_score),
        ]
        report = GuardrailReport(verdicts=verdicts)
        self._audit("pre_generation", query_request.text, report)
        return report

    def post_generation_check(self, answer_text: str, retrieval_output: RetrievalOutput) -> GuardrailReport:
        verdicts: List[GuardrailVerdict] = [
            check_groundedness(answer_text, retrieval_output, min_overlap_ratio=self.min_overlap_ratio),
        ]
        report = GuardrailReport(verdicts=verdicts)
        self._audit("post_generation", answer_text, report)
        return report

    def _audit(self, stage: str, subject_text: str, report: GuardrailReport) -> None:
        entry = {
            "guardrail_stage": stage,
            "subject_preview": subject_text[:120],
            "all_passed": report.all_passed,
            "verdicts": [v.model_dump() for v in report.verdicts],
        }
        self.audit_logger.log("guardrail_decision", **entry)
        logger.info("guardrail_decision %s", entry)
