"""
Unsafe/inappropriate input handling: a lightweight, local, rule-based content
filter (no paid moderation API). This is intentionally a coarse first line
of defense — flags queries in obviously unsafe categories so they never
reach retrieval/generation. Not a substitute for a full trust & safety
system; documented as a known limitation in the write-up (Part 10).

Design (v2): the original version matched 4 rigid full-phrase regexes
("how do i make a bomb") which missed trivial paraphrases ("how can i
build an explosive device"). This version separates each category into
an intent-verb set and a target-noun set and flags a match when a verb
and a noun from the SAME category both appear in the query (in either
order, with common filler words between them) — closer to how a
lightweight classifier would generalize, while staying dependency-free.
"""
import re
from dataclasses import dataclass
from typing import List

from orchestration.schemas import GuardrailVerdict


@dataclass
class _Category:
    name: str
    verbs: List[str]
    nouns: List[str]
    # some categories are noun-only (no verb needed to be unsafe)
    noun_only: bool = False


_CATEGORIES = [
    _Category(
        name="weapons_explosives",
        verbs=["make", "build", "synthesize", "create", "construct", "assemble", "3d print"],
        nouns=["bomb", "weapon", "explosive", "pipe bomb", "detonator", "grenade", "improvised explosive",
               "chemical weapon", "biological weapon", "nerve agent"],
    ),
    _Category(
        name="violence_self_harm",
        verbs=["kill", "murder", "harm", "hurt", "attack", "poison"],
        nouns=["myself", "someone", "a person", "my family", "them", "him", "her"],
    ),
    _Category(
        name="illegal_hacking",
        verbs=["hack", "exploit", "breach", "bypass", "crack"],
        nouns=["without permission", "illegally", "someone's account", "a system i don't own",
               "their password", "security without authorization"],
    ),
    _Category(
        name="csae",
        # Flagged as noun-only and deliberately kept to broad category terms
        # rather than an exhaustive phrase list — see note in
        # check_unsafe_input() about why this file does not attempt to be
        # a comprehensive slang/euphemism detector.
        verbs=[],
        nouns=["child sexual", "child abuse material", "csam", "sexualize a minor",
               "child exploitation"],
        noun_only=True,
    ),
]

# Character-based filler window between a verb and noun match (not a fixed
# word-token count) so contractions/possessives ("someone else's password")
# and punctuation don't silently break proximity matching.
_FILLER_CHARS = 40


def _build_proximity_pattern(verb: str, noun: str) -> re.Pattern:
    v = re.escape(verb)
    n = re.escape(noun)
    gap = rf".{{0,{_FILLER_CHARS}}}?"
    # verb ... noun OR noun ... verb, within a small character window
    return re.compile(rf"\b{v}\b{gap}\b{n}\b|\b{n}\b{gap}\b{v}\b", re.I)


def _build_noun_pattern(noun: str) -> re.Pattern:
    return re.compile(rf"\b{re.escape(noun)}\b", re.I)


def check_unsafe_input(query_text: str) -> GuardrailVerdict:
    """Coarse rule-based screen. NOT a comprehensive safety classifier —
    a real deployment should swap this for a small fine-tuned
    text-classification model while keeping the same GuardrailVerdict
    interface. This file intentionally does not attempt to enumerate
    every unsafe phrasing (especially for the csae category, where an
    exhaustive term list would itself be a misuse risk) — it demonstrates
    the guardrail *mechanism* the harness enforces, not a production-grade
    filter."""
    for category in _CATEGORIES:
        if category.noun_only:
            for noun in category.nouns:
                if _build_noun_pattern(noun).search(query_text):
                    return GuardrailVerdict(
                        check_name="unsafe_input",
                        passed=False,
                        reason=f"Query matched an unsafe-content pattern ({category.name}) and was blocked before retrieval.",
                        score=1.0,
                    )
            continue

        for verb in category.verbs:
            for noun in category.nouns:
                if _build_proximity_pattern(verb, noun).search(query_text):
                    return GuardrailVerdict(
                        check_name="unsafe_input",
                        passed=False,
                        reason=f"Query matched an unsafe-content pattern ({category.name}) and was blocked before retrieval.",
                        score=1.0,
                    )

    return GuardrailVerdict(
        check_name="unsafe_input",
        passed=True,
        reason="No unsafe-content patterns matched.",
        score=0.0,
    )
