"""
Groundedness / hallucination check: runs AFTER generation to verify the
answer's claims are actually supported by the retrieved chunks.

Two free/local signals combined:
  1. Citation check: every cited chunk_id in the answer must exist in the
     set of retrieved chunk_ids (catches fabricated/mismatched citations).
  2. Lexical overlap check: word-overlap ratio between the answer text and
     the concatenated retrieved context (catches ungrounded free-form text
     that doesn't cite anything and doesn't overlap the source material).

This is a free-tier-safe alternative to a full NLI entailment model; an NLI
model (e.g. a local cross-encoder) can be swapped in via `nli_check_fn`
without changing the calling convention.
"""
import re
from typing import List, Optional, Callable

from orchestration.schemas import RetrievalOutput, GuardrailVerdict

_CITATION_RE = re.compile(r"\[source:([a-f0-9]{16})\]")
_WORD_RE = re.compile(r"[a-z0-9']+")

DEFAULT_MIN_OVERLAP_RATIO = 0.15


def _tokenize(text: str) -> set:
    return set(_WORD_RE.findall(text.lower()))


def _extract_cited_ids(answer_text: str) -> List[str]:
    return _CITATION_RE.findall(answer_text)


def check_groundedness(
    answer_text: str,
    retrieval_output: RetrievalOutput,
    min_overlap_ratio: float = DEFAULT_MIN_OVERLAP_RATIO,
    nli_check_fn: Optional[Callable[[str, str], bool]] = None,
) -> GuardrailVerdict:
    retrieved_ids = {c.chunk_id for c in retrieval_output.chunks}
    context_text = " ".join(c.text for c in retrieval_output.chunks)

    # Signal 1: citation validity (only meaningful if the generator emits citations)
    cited_ids = _extract_cited_ids(answer_text)
    if cited_ids:
        bogus = [cid for cid in cited_ids if cid not in retrieved_ids]
        if bogus:
            return GuardrailVerdict(
                check_name="groundedness",
                passed=False,
                reason=f"Answer cites chunk id(s) not present in retrieved context: {bogus}",
                score=0.0,
            )

    # Signal 2: lexical overlap between answer and retrieved context
    answer_tokens = _tokenize(answer_text)
    context_tokens = _tokenize(context_text)
    if not answer_tokens:
        return GuardrailVerdict(check_name="groundedness", passed=False, reason="Empty answer text.", score=0.0)

    overlap = answer_tokens & context_tokens
    overlap_ratio = len(overlap) / len(answer_tokens)

    # Signal 3 (optional): pluggable NLI entailment check for stronger guarantees
    if nli_check_fn is not None:
        entailed = nli_check_fn(answer_text, context_text)
        if not entailed:
            return GuardrailVerdict(
                check_name="groundedness",
                passed=False,
                reason="NLI check: answer not entailed by retrieved context.",
                score=overlap_ratio,
            )

    passed = overlap_ratio >= min_overlap_ratio
    reason = (
        f"Lexical overlap {overlap_ratio:.2f} meets groundedness threshold {min_overlap_ratio}"
        if passed
        else f"Lexical overlap {overlap_ratio:.2f} below groundedness threshold {min_overlap_ratio} — "
             f"answer may not be supported by retrieved chunks."
    )
    return GuardrailVerdict(check_name="groundedness", passed=passed, reason=reason, score=round(overlap_ratio, 4))
