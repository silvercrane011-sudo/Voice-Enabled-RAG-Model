# Voice-to-Answer RAG Pipeline (Free-Tier Only)

A speech-to-text → retrieval-augmented-generation pipeline built entirely on
free-tier, open-source, and self-hosted components. See `ARCHITECTURE.md`
for design rationale and `TOOLS.md` for the full tool/license/free-tier-limit
audit.

## Project structure

```
rag_pipeline/
├── config.py                  # central config, all free-tier params
├── pipeline.py                 # VoiceRAGPipeline — main entrypoint
├── stt/                        # Part 1: speech-to-text
│   ├── validation.py            audio format/duration/size validation
│   ├── provider.py              Sarvam/ElevenLabs + retry/backoff
│   └── local_fallback.py        faster-whisper offline fallback
├── chunking/                   # Parts 2-3: multi-strategy chunking
│   ├── fixed_size.py             baseline, 400 tok / 15% overlap
│   ├── semantic.py                embedding-breakpoint chunking
│   ├── structure_aware.py         transcript/markdown-aware chunking
│   ├── hierarchical.py            parent/child chunking
│   └── router.py                  auto-detects doc type, dispatches strategy
├── indexing/                   # Part 4: hybrid retrieval
│   ├── dense_store.py             FAISS vector store
│   ├── sparse_store.py            BM25 keyword store
│   └── hybrid_retriever.py        RRF fusion + strategy-hit logging
├── orchestration/               # Parts 5 & 7: harness + latency
│   ├── schemas.py                 Pydantic I/O models, every stage
│   ├── steps.py                   retrieval/rerank/generation as tool calls
│   ├── harness.py                 RAGOrchestrator, error recovery
│   └── perf.py                    query cache, parallel dense+sparse search
├── guardrails/                  # Part 6: refusal logic
│   ├── off_topic.py                similarity-to-corpus threshold
│   ├── safety_filter.py            local rule-based input filter
│   ├── groundedness.py             citation + overlap check
│   └── pipeline.py                 combined pre/post gate + audit log
├── benchmark/                   # Part 8: latency benchmarking
│   ├── corpus.py                   59-query test set
│   ├── percentiles.py              P50/P70/P100 calculation
│   └── run_benchmark.py            runner, prints table + writes CSV
├── logs/                        # JSONL structured logs + benchmark CSV
├── ARCHITECTURE.md              # design write-up (deliverable #2)
└── TOOLS.md                     # tool/license/free-tier audit (deliverable #4)
```

## Quick start

```bash
pip install -r requirements.txt --break-system-packages

# Optional but recommended for full quality (falls back gracefully if absent):
pip install sentence-transformers faster-whisper tiktoken --break-system-packages

export SARVAM_API_KEY=...        # optional — falls back to faster-whisper if unset/exhausted
export ELEVENLABS_API_KEY=...    # optional alternate provider

python3 -c "
from pipeline import VoiceRAGPipeline
pipe = VoiceRAGPipeline()
pipe.ingest_text('Your document text here.', source_id='doc1')
answer = pipe.ask_text('Your question here?')
print(answer.status, answer.answer_text)
"
```

## Running the benchmark (deliverable #3)

```bash
PYTHONPATH=. python3 benchmark/run_benchmark.py
```

Prints a P50/P70/P100 table broken out by stage (retrieval, guardrails_pre,
rerank, generation, guardrails_post, total) across 59 distinct queries, and
writes `logs/benchmark_results.csv` for reproducibility. Last run:
**TOTAL P100 ≈ 2.2ms**, well inside the 200ms retrieval+generation budget
(STT is treated as a separate upstream stage — see `ARCHITECTURE.md` §4).

## Notes on running without optional dependencies

Every optional free/local model (`sentence-transformers`, `faster-whisper`,
`tiktoken`) has a deterministic, dependency-free fallback so the pipeline
never hard-crashes if one is missing — it just degrades in quality
(hashing-based embeddings instead of real semantic embeddings, etc.), with a
warning logged. This was verified throughout development in a sandboxed
environment without those packages installed.
