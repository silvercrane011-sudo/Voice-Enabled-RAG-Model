"""
Generic retry-with-backoff utility (reused by the orchestrator for model
calls and vector DB calls, per spec) and a structured JSON-lines logger for
full stage-by-stage debuggability.
"""
import time
import json
import logging
import functools
from datetime import datetime, timezone
from typing import Callable, Type, Tuple

logger = logging.getLogger("orchestration")


def retry_with_backoff(
    max_retries: int = 2,
    backoff_base_seconds: float = 0.3,
    exceptions: Tuple[Type[BaseException], ...] = (Exception,),
):
    """Decorator: retries the wrapped callable on the given exception types,
    with exponential backoff, matching the pattern used in stt/provider.py
    (Part 1) so retry behavior is consistent across the whole pipeline."""

    def decorator(fn: Callable):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            last_err = None
            for attempt in range(max_retries + 1):
                try:
                    return fn(*args, **kwargs)
                except exceptions as e:
                    last_err = e
                    if attempt < max_retries:
                        sleep_s = backoff_base_seconds * (2 ** attempt)
                        logger.warning(
                            "%s attempt %d/%d failed (%s); retrying in %.2fs",
                            fn.__name__, attempt + 1, max_retries + 1, e, sleep_s,
                        )
                        time.sleep(sleep_s)
                    else:
                        logger.error("%s exhausted all %d attempts", fn.__name__, max_retries + 1)
            raise last_err

        return wrapper

    return decorator


class StructuredLogger:
    """Writes one JSON object per line to a log file — every stage's input
    size, output size, latency, and pass/fail status — for post-hoc
    debugging and the benchmark harness (Part 8) to consume."""

    def __init__(self, path: str = "logs/orchestration.jsonl"):
        self.path = path
        import os
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

    def log(self, stage: str, **fields) -> None:
        entry = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "stage": stage,
            **fields,
        }
        with open(self.path, "a") as f:
            f.write(json.dumps(entry, default=str) + "\n")
        logger.info("stage=%s %s", stage, fields)
