"""
Distinct, individually-callable orchestration steps — NOT one giant prompt.
The harness (harness.py) invokes these as discrete tool-calling steps so each
is independently testable, retryable, and loggable.

Generation step is pluggable: `generate_fn` defaults to a free, local,
extractive synthesizer (no LLM API call, zero cost) but can be swapped for
any real free-tier LLM call (see `make_llm_generate_fn` docstring) without
touching the orchestrator.
"""
import time
import logging
from typing import List, Callable, Optional

from indexing.hybrid_retriever import HybridRetriever
from orchestration.schemas import RetrievalOutput, RetrievedChunkModel
from orchestration.utils import retry_with_backoff

logger = logging.getLogger("orchestration.steps")


# ---------------------------------------------------------------------------
# Step 1: Retrieval
# ---------------------------------------------------------------------------
@retry_with_backoff(max_retries=2, backoff_base_seconds=0.2, exceptions=(RuntimeError, OSError))
def retrieval_step(retriever: HybridRetriever, query: str, top_k: int = 5, metadata_filter=None) -> RetrievalOutput:
    t0 = time.perf_counter()
    results = retriever.search(query, top_k=top_k, metadata_filter=metadata_filter)
    latency_ms = (time.perf_counter() - t0) * 1000

    chunk_models = [
        RetrievedChunkModel(
            chunk_id=r.chunk.chunk_id,
            text=r.chunk.text,
            source_id=r.chunk.metadata.source_id,
            chunk_strategy=r.chunk_strategy,
            rrf_score=r.rrf_score,
            dense_rank=r.dense_rank,
            sparse_rank=r.sparse_rank,
            speaker=r.chunk.metadata.speaker,
            section_title=r.chunk.metadata.section_title,
            timestamp_range=r.chunk.metadata.timestamp_range,
        )
        for r in results
    ]
    return RetrievalOutput(query=query, chunks=chunk_models, retrieval_latency_ms=round(latency_ms, 3))


# ---------------------------------------------------------------------------
# Step 2: Reranking (lightweight, local, free — score-based re-ordering with
# tie-breaking toward chunks whose section/speaker metadata is present, since
# richer metadata tends to indicate cleaner source structure)
# ---------------------------------------------------------------------------
def rerank_step(retrieval_output: RetrievalOutput, top_n: Optional[int] = None) -> RetrievalOutput:
    def score(c: RetrievedChunkModel) -> float:
        bonus = 0.0
        if c.section_title or c.speaker:
            bonus += 0.001  # small tie-break nudge, doesn't override RRF ordering
        return c.rrf_score + bonus

    ranked = sorted(retrieval_output.chunks, key=score, reverse=True)
    if top_n is not None:
        ranked = ranked[:top_n]
    return RetrievalOutput(
        query=retrieval_output.query,
        chunks=ranked,
        retrieval_latency_ms=retrieval_output.retrieval_latency_ms,
    )


# ---------------------------------------------------------------------------
# Step 3: Answer generation
# ---------------------------------------------------------------------------
def local_extractive_generate(query: str, chunks: List[RetrievedChunkModel]) -> str:
    """Free, local, zero-latency-cost fallback generator: synthesizes an
    answer by stitching the top retrieved chunks with citation markers.
    No LLM API call — this is what runs when no external LLM is configured,
    keeping the whole pipeline free-tier-safe by default."""
    if not chunks:
        return ""
    parts = []
    for c in chunks:
        parts.append(f"{c.text.strip()} [source:{c.chunk_id}]")
    return " ".join(parts)


def make_llm_generate_fn(call_llm: Callable[[str], str]) -> Callable:
    """Adapter: wraps any free-tier LLM call (e.g. a provider's free chat
    endpoint) into the `generate_fn(query, chunks) -> str` signature the
    harness expects, so swapping generators never touches orchestrator code.
    `call_llm` should accept a fully-assembled prompt string and return text."""

    def _generate(query: str, chunks: List[RetrievedChunkModel]) -> str:
        context = "\n".join(f"[{c.chunk_id}] {c.text}" for c in chunks)
        prompt = (
            f"Answer the question using ONLY the context below. Cite chunk ids "
            f"in brackets for every claim.\n\nContext:\n{context}\n\nQuestion: {query}\nAnswer:"
        )
        return call_llm(prompt)

    return _generate


@retry_with_backoff(max_retries=2, backoff_base_seconds=0.2, exceptions=(RuntimeError, ConnectionError, TimeoutError))
def generation_step(
    query: str,
    chunks: List[RetrievedChunkModel],
    generate_fn: Callable[[str, List[RetrievedChunkModel]], str] = local_extractive_generate,
) -> str:
    if not chunks:
        raise RuntimeError("generation_step called with zero chunks — caller should have refused earlier")
    answer = generate_fn(query, chunks)
    if not answer or not answer.strip():
        raise RuntimeError("generator returned empty answer")
    return answer.strip()
