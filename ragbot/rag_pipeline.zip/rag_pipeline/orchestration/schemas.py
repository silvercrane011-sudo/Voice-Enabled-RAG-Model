"""
Structured input/output schemas for every stage of the orchestrator
(query -> retrieved chunks -> guardrail verdicts -> final answer).
Using Pydantic gives us runtime validation "for free" — if a stage produces
malformed output, model_validate raises immediately instead of silently
propagating garbage downstream.
"""
from __future__ import annotations
from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, field_validator, model_validator


class QueryRequest(BaseModel):
    text: str = Field(..., min_length=1, description="User query (post-STT transcript or typed text)")
    source: str = Field(default="voice", description="'voice' or 'text'")
    metadata_filter: Optional[Dict[str, Any]] = None
    top_k: int = Field(default=5, ge=1, le=20)

    @field_validator("text")
    @classmethod
    def not_blank(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("query text cannot be blank/whitespace-only")
        return v.strip()


class RetrievedChunkModel(BaseModel):
    chunk_id: str
    text: str
    source_id: str
    chunk_strategy: str
    rrf_score: float
    dense_rank: Optional[int] = None
    sparse_rank: Optional[int] = None
    speaker: Optional[str] = None
    section_title: Optional[str] = None
    timestamp_range: Optional[str] = None


class RetrievalOutput(BaseModel):
    query: str
    chunks: List[RetrievedChunkModel]
    retrieval_latency_ms: float
    empty: bool = False

    @model_validator(mode="after")
    def derive_empty(self):
        # NOTE: field_validator does not run on unset defaults in Pydantic v2
        # (validate_default=False by default) — model_validator(mode="after")
        # runs unconditionally after the whole model is built, which is what
        # we need for a field derived from another field.
        self.empty = len(self.chunks) == 0
        return self


class GuardrailVerdict(BaseModel):
    check_name: str
    passed: bool
    reason: str
    score: Optional[float] = None


class GuardrailReport(BaseModel):
    verdicts: List[GuardrailVerdict]
    all_passed: bool = False
    blocking_reason: Optional[str] = None

    @model_validator(mode="after")
    def derive_all_passed(self):
        self.all_passed = all(v.passed for v in self.verdicts) if self.verdicts else False
        if not self.all_passed and not self.blocking_reason:
            failed = [v for v in self.verdicts if not v.passed]
            if failed:
                self.blocking_reason = failed[0].reason
        return self


class AnswerStatus(str, Enum):
    ANSWERED = "answered"
    REFUSED = "refused"
    ERROR = "error"


class FinalAnswer(BaseModel):
    status: AnswerStatus
    answer_text: Optional[str] = None
    refusal_reason: Optional[str] = None
    cited_chunk_ids: List[str] = Field(default_factory=list)
    total_latency_ms: float = 0.0
    stage_latencies_ms: Dict[str, float] = Field(default_factory=dict)

    @property
    def display_text(self) -> str:
        """Safe text for any caller/CLI/demo to print or log.

        answer_text is None on REFUSED/ERROR by design (the message lives
        in refusal_reason instead) — callers that did answer_text[:n]
        directly would crash. Use this instead of answer_text when you
        just want something human-readable to show.
        """
        if self.status == AnswerStatus.ANSWERED:
            return self.answer_text or ""
        return self.refusal_reason or "No answer available."
