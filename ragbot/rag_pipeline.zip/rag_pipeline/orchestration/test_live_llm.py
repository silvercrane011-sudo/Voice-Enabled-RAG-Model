"""
Run this yourself, locally, with a real key set:

    export LLM_API_KEY=gsk_...                       # Groq free tier key
    python orchestration/test_live_llm.py "What is chunking?"

Or point at any other OpenAI-compatible free tier:
    export LLM_BASE_URL=https://openrouter.ai/api/v1
    export LLM_MODEL=meta-llama/llama-3.1-8b-instruct:free
    export LLM_API_KEY=sk-or-...

Or Anthropic directly:
    export LLM_PROVIDER=anthropic
    export LLM_API_KEY=sk-ant-...
    export LLM_MODEL=claude-sonnet-4-6

This could not be executed in the build sandbox this pipeline was
assembled in (network allowlist there only includes api.anthropic.com, and
no key was available even for that). Wiring, prompt assembly, and the
extractive-fallback-on-error path were all verified with a mocked LLM
call instead -- run this once locally to confirm a real provider too.
"""
import sys
sys.path.insert(0, ".")

from pipeline import VoiceRAGPipeline, llm_generate_fn  # noqa: E402


def main():
    query = sys.argv[1] if len(sys.argv) > 1 else "What is chunking?"

    pipe = VoiceRAGPipeline(generate_fn=llm_generate_fn())
    pipe.ingest_text(
        "Chunking strategies include fixed-size, semantic, structure-aware "
        "and hierarchical splitting of documents.",
        source_id="demo_doc",
    )
    answer = pipe.ask_text(query)
    print(f"status : {answer.status}")
    print(f"answer : {answer.display_text}")
    print(f"latency: {answer.total_latency_ms:.1f}ms")


if __name__ == "__main__":
    main()
