"""
The orchestration harness: invokes retrieval -> (guardrails, wired in Part 6
via `guardrail_fn`) -> rerank -> generation as distinct steps, with error
recovery at every stage so the system never crashes or returns malformed
output — it always returns a schema-valid FinalAnswer, even in failure.
"""
import time
import logging
from typing import Callable, Optional

from pydantic import ValidationError

from indexing.hybrid_retriever import HybridRetriever
from orchestration.schemas import (
    QueryRequest, RetrievalOutput, FinalAnswer, AnswerStatus, GuardrailReport,
)
from orchestration.steps import retrieval_step, rerank_step, generation_step, local_extractive_generate
from orchestration.utils import StructuredLogger

logger = logging.getLogger("orchestration.harness")


class RAGOrchestrator:
    def __init__(
        self,
        retriever: HybridRetriever,
        generate_fn: Callable = local_extractive_generate,
        guardrail_fn: Optional[Callable[[QueryRequest, RetrievalOutput], GuardrailReport]] = None,
        post_guardrail_fn: Optional[Callable[[str, RetrievalOutput], GuardrailReport]] = None,
        structured_logger: Optional[StructuredLogger] = None,
        min_retrieval_score: float = 0.0,
    ):
        self.retriever = retriever
        self.generate_fn = generate_fn
        # guardrail_fn is pluggable so Part 6's guardrail module drops in
        # without changing this class; default is a permissive no-op pass.
        self.guardrail_fn = guardrail_fn or self._noop_guardrail
        # post_guardrail_fn runs AFTER generation (groundedness/hallucination
        # check, Part 6) — default no-op pass keeps this class usable stand-alone.
        self.post_guardrail_fn = post_guardrail_fn or self._noop_post_guardrail
        self.slog = structured_logger or StructuredLogger()
        self.min_retrieval_score = min_retrieval_score

    @staticmethod
    def _noop_guardrail(query_request: QueryRequest, retrieval_output: RetrievalOutput) -> GuardrailReport:
        from orchestration.schemas import GuardrailVerdict
        return GuardrailReport(verdicts=[GuardrailVerdict(check_name="noop", passed=True, reason="no guardrail module wired in yet")])

    @staticmethod
    def _noop_post_guardrail(answer_text: str, retrieval_output: RetrievalOutput) -> GuardrailReport:
        from orchestration.schemas import GuardrailVerdict
        return GuardrailReport(verdicts=[GuardrailVerdict(check_name="noop_post", passed=True, reason="no post-guardrail module wired in yet")])

    def answer(self, raw_query: str, top_k: int = 5, metadata_filter: Optional[dict] = None) -> FinalAnswer:
        t_start = time.perf_counter()
        stage_latencies = {}

        # --- Input schema validation ---
        try:
            query_request = QueryRequest(text=raw_query, top_k=top_k, metadata_filter=metadata_filter)
        except ValidationError as e:
            self.slog.log("input_validation", passed=False, error=str(e))
            return FinalAnswer(
                status=AnswerStatus.REFUSED,
                refusal_reason=f"Invalid query input: {e}",
                total_latency_ms=round((time.perf_counter() - t_start) * 1000, 3),
            )
        self.slog.log("input_validation", passed=True, query=query_request.text)

        # --- Stage 1: Retrieval (with recovery if it errors or returns nothing) ---
        t0 = time.perf_counter()
        try:
            retrieval_output = retrieval_step(
                self.retriever, query_request.text, top_k=query_request.top_k,
                metadata_filter=query_request.metadata_filter,
            )
        except Exception as e:
            self.slog.log("retrieval", passed=False, error=str(e))
            return self._error_answer("Retrieval failed after retries", stage_latencies, t_start)
        stage_latencies["retrieval_ms"] = round((time.perf_counter() - t0) * 1000, 3)
        self.slog.log("retrieval", passed=True, num_chunks=len(retrieval_output.chunks),
                       latency_ms=stage_latencies["retrieval_ms"])

        if retrieval_output.empty:
            self.slog.log("retrieval", passed=False, error="no chunks retrieved")
            return self._refused_answer(
                "No relevant information was found in the indexed dataset for this query.",
                stage_latencies, t_start,
            )

        # --- Stage 2: Guardrails (pre-generation checks; full module in Part 6) ---
        t0 = time.perf_counter()
        guardrail_report = self.guardrail_fn(query_request, retrieval_output)
        stage_latencies["guardrails_pre_ms"] = round((time.perf_counter() - t0) * 1000, 3)
        self.slog.log(
            "guardrails_pre", passed=guardrail_report.all_passed,
            verdicts=[v.model_dump() for v in guardrail_report.verdicts],
        )
        if not guardrail_report.all_passed:
            return self._refused_answer(
                guardrail_report.blocking_reason or "Query blocked by guardrails.",
                stage_latencies, t_start,
            )

        # --- Stage 3: Rerank ---
        t0 = time.perf_counter()
        reranked = rerank_step(retrieval_output, top_n=query_request.top_k)
        stage_latencies["rerank_ms"] = round((time.perf_counter() - t0) * 1000, 3)
        self.slog.log("rerank", passed=True, num_chunks=len(reranked.chunks))

        # --- Stage 4: Generation (with recovery) ---
        t0 = time.perf_counter()
        try:
            answer_text = generation_step(query_request.text, reranked.chunks, generate_fn=self.generate_fn)
        except Exception as e:
            self.slog.log("generation", passed=False, error=str(e))
            return self._error_answer("Answer generation failed after retries", stage_latencies, t_start)
        stage_latencies["generation_ms"] = round((time.perf_counter() - t0) * 1000, 3)
        self.slog.log("generation", passed=True, answer_len=len(answer_text),
                       latency_ms=stage_latencies["generation_ms"])

        # --- Stage 5: Post-generation guardrails (groundedness/hallucination check) ---
        t0 = time.perf_counter()
        post_report = self.post_guardrail_fn(answer_text, reranked)
        stage_latencies["guardrails_post_ms"] = round((time.perf_counter() - t0) * 1000, 3)
        self.slog.log(
            "guardrails_post", passed=post_report.all_passed,
            verdicts=[v.model_dump() for v in post_report.verdicts],
        )
        if not post_report.all_passed:
            return self._refused_answer(
                post_report.blocking_reason or "Generated answer failed the groundedness check.",
                stage_latencies, t_start,
            )

        cited_ids = [c.chunk_id for c in reranked.chunks]
        total_ms = round((time.perf_counter() - t_start) * 1000, 3)
        final = FinalAnswer(
            status=AnswerStatus.ANSWERED,
            answer_text=answer_text,
            cited_chunk_ids=cited_ids,
            total_latency_ms=total_ms,
            stage_latencies_ms=stage_latencies,
        )
        self.slog.log("final", status=final.status.value, total_latency_ms=total_ms)
        return final

    def _refused_answer(self, reason: str, stage_latencies: dict, t_start: float) -> FinalAnswer:
        final = FinalAnswer(
            status=AnswerStatus.REFUSED,
            refusal_reason=f"I don't have enough grounded information to answer this. {reason}",
            total_latency_ms=round((time.perf_counter() - t_start) * 1000, 3),
            stage_latencies_ms=stage_latencies,
        )
        self.slog.log("final", status=final.status.value, reason=reason)
        return final

    def _error_answer(self, reason: str, stage_latencies: dict, t_start: float) -> FinalAnswer:
        final = FinalAnswer(
            status=AnswerStatus.ERROR,
            refusal_reason=reason,
            total_latency_ms=round((time.perf_counter() - t_start) * 1000, 3),
            stage_latencies_ms=stage_latencies,
        )
        self.slog.log("final", status=final.status.value, reason=reason)
        return final
