"""
Real LLM call implementations, adapted into the pipeline's
`generate_fn(query, chunks) -> str` shape via
orchestration.steps.make_llm_generate_fn.

Default provider is "openai_compatible" pointed at Groq's free tier
(fast, generous free quota, OpenAI-compatible /chat/completions shape —
same adapter also works unchanged against OpenRouter/Together/Fireworks
by changing LLM_BASE_URL/LLM_MODEL). "anthropic" calls the Messages API
directly if you'd rather use an Anthropic key.

Set before running:
    export LLM_API_KEY=...
    export LLM_PROVIDER=openai_compatible   # or "anthropic"
    export LLM_BASE_URL=https://api.groq.com/openai/v1   # if not Groq
    export LLM_MODEL=llama-3.1-8b-instant

NOTE ON SANDBOX LIMITS: this file was written and unit-tested (prompt
assembly, retry/error handling) in an environment whose network allowlist
only includes api.anthropic.com — not Groq/OpenRouter/Together. A live
call was never executed here. Run scripts/test_live_llm.py locally with a
real key before relying on this for your demo.
"""
import time
import logging
from typing import Optional

import requests

from config import CONFIG

logger = logging.getLogger("orchestration.llm_provider")


class LLMProviderError(RuntimeError):
    pass


def _call_openai_compatible(prompt: str) -> str:
    cfg = CONFIG.llm
    if not cfg.api_key:
        raise LLMProviderError("LLM_API_KEY not set in environment")
    resp = requests.post(
        f"{cfg.base_url.rstrip('/')}/chat/completions",
        headers={"Authorization": f"Bearer {cfg.api_key}"},
        json={
            "model": cfg.model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": cfg.max_tokens,
            "temperature": cfg.temperature,
        },
        timeout=cfg.request_timeout_seconds,
    )
    if resp.status_code == 429:
        raise LLMProviderError("LLM free-tier quota exhausted (HTTP 429)")
    if not resp.ok:
        raise LLMProviderError(f"LLM API error {resp.status_code}: {resp.text[:200]}")
    data = resp.json()
    try:
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError) as e:
        raise LLMProviderError(f"Unexpected response shape: {data}") from e


def _call_anthropic(prompt: str) -> str:
    cfg = CONFIG.llm
    if not cfg.api_key:
        raise LLMProviderError("LLM_API_KEY not set in environment")
    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": cfg.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        json={
            "model": cfg.model or "claude-sonnet-4-6",
            "max_tokens": cfg.max_tokens,
            "messages": [{"role": "user", "content": prompt}],
        },
        timeout=cfg.request_timeout_seconds,
    )
    if resp.status_code == 429:
        raise LLMProviderError("Anthropic quota/rate limit hit (HTTP 429)")
    if not resp.ok:
        raise LLMProviderError(f"Anthropic API error {resp.status_code}: {resp.text[:200]}")
    data = resp.json()
    try:
        return "".join(block["text"] for block in data["content"] if block.get("type") == "text")
    except (KeyError, TypeError) as e:
        raise LLMProviderError(f"Unexpected response shape: {data}") from e


_PROVIDER_FUNCS = {
    "openai_compatible": _call_openai_compatible,
    "anthropic": _call_anthropic,
}


def call_llm_with_retry(prompt: str, provider: Optional[str] = None) -> str:
    """Same retry/backoff shape as stt.provider._call_with_retry, kept
    consistent across the codebase rather than inventing a new pattern."""
    cfg = CONFIG.llm
    provider = provider or cfg.provider
    fn = _PROVIDER_FUNCS.get(provider)
    if fn is None:
        raise LLMProviderError(f"Unknown LLM provider '{provider}'")

    last_err = None
    for attempt in range(cfg.max_retries + 1):
        try:
            return fn(prompt)
        except (requests.Timeout, requests.ConnectionError, LLMProviderError) as e:
            last_err = e
            if attempt < cfg.max_retries:
                sleep_s = cfg.backoff_base_seconds * (2 ** attempt)
                logger.warning(
                    "%s LLM attempt %d/%d failed (%s); retrying in %.2fs",
                    provider, attempt + 1, cfg.max_retries + 1, e, sleep_s,
                )
                time.sleep(sleep_s)
    raise LLMProviderError(f"{provider} LLM failed after retries: {last_err}")
