"""
Latency optimization utilities for the <200ms retrieval+generation budget.

ASSUMPTION (per spec section 3): STT is measured as a separate upstream
stage (it involves a network call to Sarvam/ElevenLabs or local Whisper
inference and cannot realistically fit inside 200ms). The 200ms-critical
section measured here is: query received (post-STT) -> retrieval ->
context assembly -> generation -> final output.

Techniques applied in this module:
  1. In-memory LRU query-embedding cache — repeated/similar queries in a
     session skip re-embedding.
  2. A thread pool to run dense (FAISS) and sparse (BM25) search
     concurrently instead of sequentially (both are CPU-bound, released-GIL
     C code inside FAISS; BM25 in pure Python still benefits from overlap
     with FAISS's C++ execution).
  3. A `Timer` context manager for fine-grained stage measurement, reused
     by the benchmark harness (Part 8).
"""
import time
import logging
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from typing import Callable, Tuple, Any
from contextlib import contextmanager

import numpy as np

logger = logging.getLogger("orchestration.perf")

_EXECUTOR = ThreadPoolExecutor(max_workers=4, thread_name_prefix="rag-io")


@contextmanager
def timer():
    """Usage: with timer() as t: ...  ->  t.elapsed_ms available after the block."""
    state = {"elapsed_ms": None}
    t0 = time.perf_counter()
    try:
        yield state
    finally:
        state["elapsed_ms"] = (time.perf_counter() - t0) * 1000


class QueryEmbeddingCache:
    """Tiny LRU cache keyed on exact query text. Free, in-memory, no external
    cache service (keeps this free-tier-safe). Exact-match only by design —
    a semantic cache (embedding-similarity cache hits) is noted as a future
    upgrade in the write-up (Part 10), since it adds its own latency cost
    (a similarity search just to decide whether to skip a similarity search)
    that isn't obviously worth it below ~1k QPS.
    """

    def __init__(self, maxsize: int = 256):
        self._cache: dict = {}
        self._order: list = []
        self.maxsize = maxsize
        self.hits = 0
        self.misses = 0

    def get_or_compute(self, query: str, compute_fn: Callable[[], np.ndarray]) -> np.ndarray:
        if query in self._cache:
            self.hits += 1
            self._order.remove(query)
            self._order.append(query)
            return self._cache[query]

        self.misses += 1
        result = compute_fn()
        self._cache[query] = result
        self._order.append(query)
        if len(self._order) > self.maxsize:
            oldest = self._order.pop(0)
            del self._cache[oldest]
        return result

    def stats(self) -> dict:
        total = self.hits + self.misses
        return {
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": round(self.hits / total, 3) if total else 0.0,
            "size": len(self._cache),
        }


def run_parallel(fn_a: Callable[[], Any], fn_b: Callable[[], Any]) -> Tuple[Any, Any]:
    """Runs two blocking callables concurrently on the shared thread pool and
    returns their results as a tuple, preserving order. Used to overlap
    dense-store and sparse-store search calls."""
    future_a = _EXECUTOR.submit(fn_a)
    future_b = _EXECUTOR.submit(fn_b)
    return future_a.result(), future_b.result()
